/**
 * TaskBridge host core — pure-ish helpers shared by the Host plugin and tests:
 * the persistent task-plan fold, the JSON model-provider store, and calls to
 * user-configured OpenAI-compatible text/image/video endpoints.
 *
 * No Cordis or DSH imports: only Node built-ins, so this file can be unit
 * tested outside the Harness.
 */
import fs from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import { randomUUID } from 'node:crypto'

export const PLUGIN_ID = 'taskbridge'
export const PROJECTION_KEY = 'taskbridgePlan'
export const PLAN_TOOL = 'task_plan'
export const UPDATE_TOOL = 'task_update'
export const CONSULT_TOOL = 'external_model_consult'
export const MEDIA_TOOL = 'external_media_generate'
export const PLAN_TOOLS = new Set([PLAN_TOOL, UPDATE_TOOL])

export const TASK_STATUSES = ['pending', 'in_progress', 'completed', 'blocked']
export const PROVIDER_CATEGORIES = ['text', 'image', 'video']

/** Case-insensitive marker that an activity sentence came from a plan call. */
const AUTO_CONSULT_NOTE_LIMIT = 6000
const MAX_PENDING_PLAN_CALLS = 64

/** The projection registry only calls Zod's `.parse`; a passthrough schema is valid. */
export const PASSTHROUGH_SCHEMA = {
  parse(value) {
    return value
  },
}

/**
 * Projection state schema. The registry feeds cached checkpoint values through
 * `parse` on resume, so repairing an unexpected record here keeps a corrupt
 * cache from poisoning the plan view or the prompt.
 */
export const PROJECTION_STATE_SCHEMA = {
  parse(value) {
    return normalizeProjectionState(value)
  },
}

const STATUS_PROGRESS = {
  pending: 0,
  in_progress: 50,
  completed: 100,
  blocked: 0,
}

const DEFAULT_PATHS = {
  text: '/chat/completions',
  image: '/images/generations',
  video: '/videos/generations',
}

const DEFAULT_PROTOCOLS = {
  text: 'openai-chat',
  image: 'openai-images',
  video: 'openai-video',
}

/** Resolve the harness home exactly like dsh-home-paths: DSH_HOME, else ~/.dsh. */
export function resolveDshHome() {
  const configured = process.env.DSH_HOME?.trim()
  if (configured) return path.resolve(expandTilde(configured))
  return path.join(os.homedir(), '.dsh')
}

export function configPath() {
  return path.join(resolveDshHome(), 'taskbridge', 'models.json')
}

export function auditPath() {
  return path.join(resolveDshHome(), 'taskbridge', 'audit.jsonl')
}

export function planWorkspaceFile(cwd) {
  return path.join(cwd, '.dsh-taskbridge', 'TASKBOARD.md')
}

export function defaultConfig() {
  return {
    version: 1,
    autoConsult: {
      enabled: true,
      afterErrors: 3,
      cooldownSec: 120,
      maxTokens: 1200,
    },
    providers: [],
  }
}

function expandTilde(value) {
  if (value === '~') return os.homedir()
  if (value.startsWith('~/') || value.startsWith('~\\')) {
    return path.join(os.homedir(), value.slice(2))
  }
  return value
}

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

function asString(value, fallback = '') {
  return typeof value === 'string' ? value.trim() : fallback
}

function asInt(value, fallback, min, max) {
  const number = typeof value === 'number' ? value : Number.parseInt(String(value), 10)
  if (!Number.isFinite(number)) return fallback
  return Math.min(max, Math.max(min, Math.trunc(number)))
}

function asObject(value, fallback = {}) {
  if (isPlainObject(value)) return value
  if (typeof value === 'string' && value.trim() !== '') {
    try {
      const parsed = JSON.parse(value)
      return isPlainObject(parsed) ? parsed : fallback
    } catch {
      return fallback
    }
  }
  return fallback
}

function safeJson(value) {
  try {
    const text = JSON.stringify(value)
    return typeof text === 'string' ? text : 'null'
  } catch {
    return 'null'
  }
}

/* ------------------------------------------------------------------ plan -- */

function nowMs() {
  return Date.now()
}

function taskIdCandidate(raw, index) {
  const id = asString(raw?.id)
  if (/^[A-Za-z0-9_-]{1,40}$/.test(id)) return id
  return `T${index + 1}`
}

function normalizeStatus(value) {
  return TASK_STATUSES.includes(value) ? value : 'pending'
}

function normalizeProgress(value, status) {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return Math.min(100, Math.max(0, Math.round(value)))
  }
  return STATUS_PROGRESS[status] ?? 0
}

export function normalizeTask(raw, index, now = nowMs()) {
  const status = normalizeStatus(raw?.status)
  const id = taskIdCandidate(raw, index)
  return {
    id,
    title: asString(raw?.title) || `任务 ${index + 1}`,
    assignee: asString(raw?.assignee) || 'DeepSeek',
    status,
    progress: normalizeProgress(raw?.progress, status),
    notes: asString(raw?.notes),
    updatedAt: now,
  }
}

export function normalizeTasks(rawTasks, now = nowMs()) {
  const source = Array.isArray(rawTasks) ? rawTasks : []
  const used = new Set()
  return source.map((raw, index) => {
    const task = normalizeTask(raw, index, now)
    let id = task.id
    let suffix = 2
    while (used.has(id)) {
      id = `${task.id}-${suffix++}`
    }
    used.add(id)
    return { ...task, id }
  })
}

/**
 * Validate a model-supplied plan before it becomes a tool success. Raw
 * ToolDefinitions are not argument-validated by the registry, so an empty
 * `tasks` array must be rejected here: a committed empty plan would replace a
 * live plan with nothing and leave the projection with no foldable work.
 *
 * @param input - the `plan` argument of task_plan create/replace.
 * @returns the validated input (same reference).
 * @throws when the plan is not an object or carries no usable task.
 */
export function assertPlanInput(input) {
  if (!isPlainObject(input)) throw new Error('plan must be an object with a non-empty "tasks" array')
  if (!Array.isArray(input.tasks) || input.tasks.length === 0) {
    throw new Error('plan.tasks must contain at least one task')
  }
  input.tasks.forEach((task, index) => {
    if (!isPlainObject(task)) throw new Error(`plan.tasks[${index}] must be an object`)
    if (asString(task.title) === '') throw new Error(`plan.tasks[${index}].title is required`)
  })
  return input
}

function activityEntry(at, text) {
  return { at, text }
}

function pushActivity(activity, entry, limit = 40) {
  const next = [...(Array.isArray(activity) ? activity : []), entry]
  return next.length > limit ? next.slice(next.length - limit) : next
}

export function buildPlan(input, existing, now = nowMs()) {
  const tasks = normalizeTasks(input?.tasks, now)
  const plan = {
    version: 1,
    title: asString(input?.title) || existing?.title || '任务计划书',
    goal: asString(input?.goal) || existing?.goal || '',
    notes: asString(input?.notes) || existing?.notes || '',
    tasks,
    revision: (existing?.revision ?? 0) + 1,
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
    activity: pushActivity(existing?.activity, activityEntry(now, existing ? '计划已更新' : '计划已创建')),
  }
  return plan
}

export function taskStatusCounts(plan) {
  const counts = { pending: 0, in_progress: 0, completed: 0, blocked: 0, total: 0 }
  for (const task of plan?.tasks ?? []) {
    counts.total += 1
    if (counts[task.status] !== undefined) counts[task.status] += 1
  }
  return counts
}

export function planProgress(plan) {
  const tasks = plan?.tasks ?? []
  if (tasks.length === 0) return 0
  const sum = tasks.reduce((acc, task) => acc + task.progress, 0)
  return Math.round(sum / tasks.length)
}

export function applyTaskUpdates(plan, updates, now = nowMs()) {
  if (!plan || !Array.isArray(plan.tasks)) return plan
  if (!Array.isArray(updates) || updates.length === 0) return plan
  let changed = false
  const byId = new Map(plan.tasks.map((task) => [task.id, task]))
  for (const raw of updates) {
    const id = asString(raw?.id)
    const current = byId.get(id)
    if (!current) continue
    const next = { ...current }
    if (raw.status !== undefined) next.status = normalizeStatus(raw.status)
    if (raw.title !== undefined) next.title = asString(raw.title) || current.title
    if (raw.assignee !== undefined) next.assignee = asString(raw.assignee) || current.assignee
    if (raw.notes !== undefined) next.notes = asString(raw.notes)
    if (raw.progress !== undefined) next.progress = normalizeProgress(raw.progress, next.status)
    else if (raw.status !== undefined && next.status !== current.status) {
      // A status change without an explicit progress derives the default band.
      next.progress = STATUS_PROGRESS[next.status] ?? next.progress
    }
    next.updatedAt = now
    if (
      next.status !== current.status ||
      next.progress !== current.progress ||
      next.assignee !== current.assignee ||
      next.title !== current.title ||
      next.notes !== current.notes
    ) {
      changed = true
    }
    byId.set(id, next)
  }
  if (!changed) return plan
  const tasks = plan.tasks.map((task) => byId.get(task.id))
  const notes = updates
    .map((raw) => asString(raw?.note))
    .filter(Boolean)
    .join('；')
  const activity = pushActivity(plan.activity, activityEntry(now, notes || '任务进度已更新'))
  return {
    ...plan,
    tasks,
    revision: (plan.revision ?? 0) + 1,
    updatedAt: now,
    activity,
  }
}

/** Apply one successful plan-tool call. The projection calls this on tool/result. */
export function applyPlanToolCall(currentPlan, pending, now = nowMs()) {
  if (!pending || !PLAN_TOOLS.has(pending.name)) return currentPlan
  const args = isPlainObject(pending.args) ? pending.args : {}
  if (pending.name === UPDATE_TOOL) {
    return applyTaskUpdates(currentPlan, args.updates, now)
  }
  const action = asString(args.action, 'create')
  if (action === 'create') {
    // `create` deliberately reuses a live plan instead of replacing it.
    if (currentPlan) return currentPlan
    return buildPlan(args.plan, null, now)
  }
  if (action === 'replace') {
    return buildPlan(args.plan, currentPlan, now)
  }
  return currentPlan
}

export function planFromProjectionState(state) {
  return state?.plan ?? null
}

/* -------------------------------------------------------------- projection -- */

export function initProjectionState() {
  return { plan: null, pending: {} }
}

/**
 * Repair a projection state read from a cached checkpoint. Every field is
 * re-derived from the live contract, so an older/garbled row materializes as
 * "no plan yet" instead of surfacing to the prompt or the Client view.
 *
 * @param value - a state-shaped value from the checkpoint cache or a test.
 * @returns a plain-JSON state usable by {@link applyProjectionEvent}.
 */
export function normalizeProjectionState(value) {
  if (!isPlainObject(value)) return initProjectionState()
  const pending = {}
  if (isPlainObject(value.pending)) {
    for (const [callId, entry] of Object.entries(value.pending)) {
      if (Object.keys(pending).length >= MAX_PENDING_PLAN_CALLS) break
      if (typeof callId !== 'string' || callId === '') continue
      if (!isPlainObject(entry) || !PLAN_TOOLS.has(entry.name)) continue
      pending[callId] = { name: entry.name, args: isPlainObject(entry.args) ? entry.args : {} }
    }
  }
  const plan =
    isPlainObject(value.plan) &&
    Array.isArray(value.plan.tasks) &&
    Array.isArray(value.plan.activity)
      ? value.plan
      : null
  return { plan, pending }
}

function parseCallArguments(raw) {
  if (isPlainObject(raw)) return raw
  if (typeof raw !== 'string') return {}
  try {
    const parsed = JSON.parse(raw)
    return isPlainObject(parsed) ? parsed : {}
  } catch {
    return {}
  }
}

function rememberPending(state, callId, name, args) {
  if (typeof callId !== 'string' || callId === '') return state
  const pending = { ...state.pending, [callId]: { name, args: parseCallArguments(args) } }
  const callIds = Object.keys(pending)
  if (callIds.length > MAX_PENDING_PLAN_CALLS) delete pending[callIds[0]]
  return { ...state, pending }
}

function settlePending(state, callId, failed, now) {
  const pendingCall = state.pending?.[callId]
  if (!pendingCall) return state
  const nextPending = { ...state.pending }
  delete nextPending[callId]
  if (failed) return { ...state, pending: nextPending }
  const nextPlan = applyPlanToolCall(state.plan, pendingCall, now)
  if (nextPlan === state.plan) return { ...state, pending: nextPending }
  return { plan: nextPlan, pending: nextPending }
}

/**
 * Pure fold over committed session events. Plan state only changes after a
 * successful `tool/result` (or a successful PTC sub-dispatch), so an
 * interrupted, denied, or failed plan call cannot leak a phantom plan into
 * replay or the Client view.
 *
 * Both the native tool pipeline (`tool/call` + `tool/result`) and the PTC
 * presentation (`tool/ptc-dispatch-start` + `tool/ptc-dispatch`) are folded, so
 * a plan stays live whichever tool presentation the user selected.
 */
export function applyProjectionEvent(state, event) {
  if (!isPlainObject(event) || !isPlainObject(state)) return state
  const data = isPlainObject(event.data) ? event.data : {}

  if (event.type === 'tool/call' && PLAN_TOOLS.has(data.name)) {
    return rememberPending(state, data.callId, data.name, data.arguments)
  }

  if (event.type === 'tool/result') {
    const callId = data.message?.toolCallId
    if (typeof callId !== 'string') return state
    const failed = Boolean(data.error) || data.message?.isError === true
    return settlePending(state, callId, failed, event.time ?? nowMs())
  }

  if (event.type === 'tool/ptc-dispatch-start' && PLAN_TOOLS.has(data.name)) {
    return rememberPending(state, data.subCallId, data.name, data.arguments)
  }

  if (event.type === 'tool/ptc-dispatch') {
    const callId = data.subCallId
    if (typeof callId !== 'string' || !state.pending?.[callId]) return state
    return settlePending(state, callId, data.isError === true, event.time ?? nowMs())
  }

  return state
}

export function renderPlanMarkdown(plan) {
  if (!plan) return '# 任务计划书\n\n（尚无计划）\n'
  const counts = taskStatusCounts(plan)
  const lines = [
    `# ${plan.title}`,
    '',
    plan.goal ? `**目标**：${plan.goal}` : '',
    plan.notes ? `**备注**：${plan.notes}` : '',
    '',
    `**进度**：${planProgress(plan)}%（${counts.completed}/${counts.total} 完成，${counts.in_progress} 进行中，${counts.pending} 待开始，${counts.blocked} 受阻）`,
    '',
    '| ID | 任务 | 负责 | 状态 | 进度 | 备注 |',
    '| --- | --- | --- | --- | --- | --- |',
    ...(plan.tasks ?? []).map(
      (task) =>
        `| ${task.id} | ${escapeCell(task.title)} | ${escapeCell(task.assignee)} | ${task.status} | ${task.progress}% | ${escapeCell(task.notes)} |`,
    ),
    '',
    `_更新于 ${new Date(plan.updatedAt).toISOString()}，修订 ${plan.revision}_`,
    '',
  ]
  return lines.filter((line, index, all) => line !== '' || all[index - 1] !== '').join('\n')
}

function escapeCell(value) {
  return String(value ?? '').replace(/\|/g, '\\|').replace(/\n/g, ' ')
}

export async function writePlanFile(plan, cwd) {
  if (!plan || !cwd) return null
  const file = planWorkspaceFile(cwd)
  await fs.mkdir(path.dirname(file), { recursive: true })
  await fs.writeFile(file, renderPlanMarkdown(plan), 'utf8')
  return file
}

/**
 * Render the prompt section body for one agent. The caller registers it with
 * `interpolate: false`, so task titles/notes carrying `{{…}}` stay literal
 * instead of failing the strict prompt-variable interpolation.
 */
export function renderPlanPrompt(plan, extra) {
  const note = typeof extra === 'string' ? extra.trim().slice(0, AUTO_CONSULT_NOTE_LIMIT) : ''
  if (!plan) {
    return note ? `TaskBridge external-advisor note:\n${note}\n` : ''
  }
  const counts = taskStatusCounts(plan)
  const tasks = (plan.tasks ?? [])
    .slice(0, 30)
    .map(
      (task) =>
        `- [${task.id}] ${String(task.status).toUpperCase()} ${task.progress}% · ${task.assignee} · ${task.title}${task.notes ? ` — ${task.notes}` : ''}`,
    )
    .join('\n')
  const omitted = plan.tasks.length > 30 ? `\n- …${plan.tasks.length - 30} more tasks` : ''
  const activity = (plan.activity ?? [])
    .slice(-3)
    .map((entry) => `- ${new Date(entry.at).toISOString()}: ${entry.text}`)
    .join('\n')
  const parts = [
    '## Persistent TaskBridge plan (log-backed; the user sees this live)',
    `Title: ${plan.title}`,
    plan.goal ? `Goal: ${plan.goal}` : '',
    `Revision: ${plan.revision} · progress ${planProgress(plan)}% · ${counts.completed}/${counts.total} completed · ${counts.in_progress} in progress · ${counts.pending} pending · ${counts.blocked} blocked`,
    tasks,
    omitted,
    activity ? `Recent activity:\n${activity}` : '',
    'Continue from this plan after compaction. Keep it current with task_update; never restart completed work without a reason.',
  ].filter(Boolean)
  if (note) parts.push(`\nExternal-advisor note (use it to get unstuck, then update the plan):\n${note}`)
  return parts.join('\n')
}

/* ----------------------------------------------------------------- config -- */

function sanitizeId(raw, fallback) {
  const value = asString(raw)
  if (/^[A-Za-z0-9_-]{1,64}$/.test(value)) return value
  return fallback
}

function parseHeaders(raw) {
  const value = asObject(raw, {})
  const headers = {}
  for (const [key, entry] of Object.entries(value)) {
    if (typeof entry === 'string') headers[key] = entry
  }
  return headers
}

function normalizeProvider(raw, existing, index) {
  if (!isPlainObject(raw)) throw new Error(`provider #${index + 1} is not an object`)
  const category = asString(raw.category, 'text')
  if (!PROVIDER_CATEGORIES.includes(category)) {
    throw new Error(`provider #${index + 1}: category must be one of ${PROVIDER_CATEGORIES.join(', ')}`)
  }
  const baseURL = asString(raw.baseURL)
  if (!baseURL) throw new Error(`provider #${index + 1}: baseURL is required`)
  let parsed
  try {
    parsed = new URL(baseURL)
  } catch {
    throw new Error(`provider #${index + 1}: baseURL is not a valid URL`)
  }
  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new Error(`provider #${index + 1}: baseURL must use http or https`)
  }
  const id = sanitizeId(raw.id, `provider-${Date.now().toString(36)}-${index + 1}`)
  const name = asString(raw.name) || `${category} endpoint ${index + 1}`
  const protocol = asString(raw.protocol) || DEFAULT_PROTOCOLS[category]
  // A client round-trip never carries the secret; only an explicit clearKey
  // removes it, and the stored value is preserved otherwise.
  const apiKey =
    raw.clearKey === true
      ? ''
      : typeof raw.apiKey === 'string' && raw.apiKey.trim() !== ''
        ? raw.apiKey.trim()
        : existing?.apiKey ?? ''
  return {
    id,
    name,
    category,
    protocol,
    baseURL: parsed.toString().replace(/\/$/, ''),
    path: asString(raw.path) || DEFAULT_PATHS[category],
    model: asString(raw.model),
    apiKey,
    headers: parseHeaders(raw.headers),
    extraBody: asObject(raw.extraBody, {}),
    enabled: raw.enabled !== false,
    timeoutMs: asInt(raw.timeoutMs, 60000, 1000, 600000),
    responsePath: asString(raw.responsePath),
    responseFormat: asString(raw.responseFormat),
    pollPath: asString(raw.pollPath),
    pollIntervalMs: asInt(raw.pollIntervalMs, 3000, 500, 60000),
    pollMaxMs: asInt(raw.pollMaxMs, 300000, 5000, 3600000),
    statusField: asString(raw.statusField, 'status') || 'status',
    resultField: asString(raw.resultField),
    successValues: asString(raw.successValues, 'succeeded,completed,success,done') || 'succeeded,completed,success,done',
    failureValues: asString(raw.failureValues, 'failed,error,cancelled,canceled') || 'failed,error,cancelled,canceled',
    note: asString(raw.note),
  }
}

/**
 * Normalize one config document. Partial documents preserve the matching
 * stored section, so a settings round-trip that omits `providers` cannot wipe
 * the user's roster, and an incoming provider without `apiKey` keeps the
 * stored secret for the same id (the Client never receives secrets).
 *
 * @param raw - incoming config (file content from disk or an HTTP body).
 * @param existing - previously stored config, used for secret/partial merges.
 */
export function normalizeConfig(raw, existing) {
  const base = defaultConfig()
  const rawObject = isPlainObject(raw) ? raw : {}
  const existingObject = isPlainObject(existing) ? existing : undefined
  const autoSource = isPlainObject(rawObject.autoConsult)
    ? rawObject.autoConsult
    : isPlainObject(existingObject?.autoConsult)
      ? existingObject.autoConsult
      : {}
  const providerSource = Array.isArray(rawObject.providers)
    ? rawObject.providers
    : Array.isArray(existingObject?.providers)
      ? existingObject.providers
      : []
  const existingById = new Map((existingObject?.providers ?? []).map((provider) => [provider.id, provider]))
  const ids = new Set()
  const providers = []
  for (const [index, entry] of providerSource.entries()) {
    const candidateId = sanitizeId(entry?.id, '')
    const provider = normalizeProvider(entry, existingById.get(candidateId), index)
    let id = provider.id
    let suffix = 2
    while (ids.has(id)) id = `${provider.id}-${suffix++}`
    ids.add(id)
    providers.push({ ...provider, id })
  }
  return {
    version: 1,
    autoConsult: {
      enabled: autoSource.enabled !== false,
      afterErrors: asInt(autoSource.afterErrors, base.autoConsult.afterErrors, 1, 20),
      cooldownSec: asInt(autoSource.cooldownSec, base.autoConsult.cooldownSec, 0, 3600),
      maxTokens: asInt(autoSource.maxTokens, base.autoConsult.maxTokens, 100, 8000),
    },
    providers,
  }
}

export async function readConfig() {
  try {
    const raw = JSON.parse(await fs.readFile(configPath(), 'utf8'))
    return normalizeConfig(raw, raw)
  } catch {
    return defaultConfig()
  }
}

export async function writeConfig(config) {
  const file = configPath()
  await fs.mkdir(path.dirname(file), { recursive: true })
  const text = `${JSON.stringify(config, null, 2)}\n`
  await fs.writeFile(file, text, { encoding: 'utf8', mode: 0o600 })
  try {
    await fs.chmod(file, 0o600)
  } catch {
    /* Windows may not implement POSIX modes; the file is still user-owned. */
  }
  return file
}

/** Client-safe config: the stored secret never crosses the HTTP boundary. */
export function sanitizeConfigForClient(config) {
  return {
    version: 1,
    autoConsult: { ...config.autoConsult },
    providers: (config.providers ?? []).map((provider) => {
      const { apiKey, ...safe } = provider
      return {
        ...safe,
        hasKey: typeof apiKey === 'string' && apiKey !== '',
        keyPreview: typeof apiKey === 'string' && apiKey !== '' ? `••••${apiKey.slice(-4)}` : '',
      }
    }),
  }
}

export function pickProvider(config, category, providerId) {
  const enabled = (config?.providers ?? []).filter((provider) => provider.enabled && provider.category === category)
  if (providerId) return enabled.find((provider) => provider.id === providerId) ?? null
  return enabled[0] ?? null
}

export async function appendAudit(record) {
  try {
    const file = auditPath()
    await fs.mkdir(path.dirname(file), { recursive: true })
    await fs.appendFile(file, `${safeJson({ at: new Date().toISOString(), ...record })}\n`, 'utf8')
  } catch {
    /* Audit is best-effort and must never break a turn. */
  }
}

/* --------------------------------------------------------------- HTTP/API -- */

function joinUrl(baseURL, subPath) {
  if (/^https?:\/\//i.test(subPath)) return subPath
  const base = baseURL.replace(/\/+$/, '')
  const suffix = subPath.startsWith('/') ? subPath : `/${subPath}`
  return `${base}${suffix}`
}

export function providerEndpoint(provider) {
  return joinUrl(provider.baseURL, provider.path || DEFAULT_PATHS[provider.category] || '')
}

function providerHeaders(provider, extra = {}) {
  const headers = { accept: 'application/json', ...provider.headers, ...extra }
  const hasAuthorization = Object.keys(headers).some((key) => key.toLowerCase() === 'authorization')
  if (provider.apiKey && !hasAuthorization) headers.authorization = `Bearer ${provider.apiKey}`
  return headers
}

function requireModel(provider) {
  if (!provider?.model) {
    throw new Error(`provider "${provider?.name ?? 'unknown'}" has no model configured; set one in Settings → TaskBridge`)
  }
}

async function withTimeout(signal, timeoutMs, operation) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(new Error(`request timed out after ${timeoutMs}ms`)), timeoutMs)
  const forwardAbort = () => controller.abort(signal?.reason ?? new Error('aborted'))
  if (signal) {
    if (signal.aborted) forwardAbort()
    else signal.addEventListener('abort', forwardAbort, { once: true })
  }
  try {
    return await operation(controller.signal)
  } finally {
    clearTimeout(timer)
    if (signal) signal.removeEventListener('abort', forwardAbort)
  }
}

async function httpJson(url, options = {}) {
  const { method = 'GET', headers = {}, body, timeoutMs = 60000, signal } = options
  return withTimeout(signal, timeoutMs, async (combinedSignal) => {
    const response = await fetch(url, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: combinedSignal,
    })
    // The body read stays inside the deadline: a stalled stream must not turn
    // `timeoutMs` into a headers-only budget.
    const text = await response.text()
    let json
    try {
      json = text ? JSON.parse(text) : undefined
    } catch {
      json = undefined
    }
    if (!response.ok) {
      const detail = (json ? safeJson(json) : text).slice(0, 800)
      throw new Error(`${response.status} ${response.statusText}: ${detail}`)
    }
    return { response, text, json }
  })
}

export function pickPath(value, expression) {
  if (!expression) return value
  const parts = []
  for (const segment of String(expression).split('.')) {
    const match = segment.match(/^([^[\]]*)((?:\[[^\]]+\])*)$/)
    if (!match) return undefined
    if (match[1]) parts.push(match[1])
    for (const bracket of match[2].matchAll(/\[([^\]]+)\]/g)) {
      const raw = bracket[1].replace(/^['"]|['"]$/g, '')
      parts.push(/^\d+$/.test(raw) ? Number(raw) : raw)
    }
  }
  let current = value
  for (const part of parts) {
    if (current === null || current === undefined) return undefined
    current = current[part]
  }
  return current
}

function textFromContent(value) {
  if (typeof value === 'string') return value
  if (Array.isArray(value)) {
    return value
      .map((entry) => {
        if (typeof entry === 'string') return entry
        if (isPlainObject(entry) && typeof entry.text === 'string') return entry.text
        return ''
      })
      .filter(Boolean)
      .join('\n')
  }
  return ''
}

export function extractText(json, provider) {
  if (provider?.responsePath) {
    const picked = pickPath(json, provider.responsePath)
    const text = textFromContent(picked)
    if (text) return text
  }
  const candidates = [
    () => pickPath(json, 'choices[0].message.content'),
    () => pickPath(json, 'choices[0].text'),
    () => pickPath(json, 'output_text'),
    () => pickPath(json, 'output[0].content[0].text'),
    () => pickPath(json, 'content[0].text'),
    () => pickPath(json, 'message.content'),
    () => pickPath(json, 'data[0].text'),
    () => pickPath(json, 'data.answer'),
    () => pickPath(json, 'result.text'),
    () => pickPath(json, 'response'),
    () => pickPath(json, 'text'),
    () => pickPath(json, 'answer'),
  ]
  for (const candidate of candidates) {
    const text = textFromContent(candidate())
    if (text.trim()) return text.trim()
  }
  return safeJson(json).slice(0, 4000)
}

export async function callTextProvider(provider, messages, options = {}) {
  requireModel(provider)
  const body = {
    model: provider.model,
    messages,
    ...(provider.extraBody ?? {}),
  }
  if (options.maxTokens && body.max_tokens === undefined && body.maxTokens === undefined) {
    body.max_tokens = options.maxTokens
  }
  if (options.temperature !== undefined && body.temperature === undefined) {
    body.temperature = options.temperature
  }
  const { json } = await httpJson(providerEndpoint(provider), {
    method: 'POST',
    headers: providerHeaders(provider, { 'content-type': 'application/json' }),
    body,
    timeoutMs: provider.timeoutMs,
    signal: options.signal,
  })
  return {
    text: extractText(json, provider),
    provider: provider.name,
    providerId: provider.id,
    model: provider.model,
  }
}

function mediaFromObject(value) {
  if (!isPlainObject(value)) return null
  for (const key of ['b64_json', 'base64', 'b64', 'image_base64', 'video_base64']) {
    if (typeof value[key] === 'string' && value[key].length > 32) return { base64: value[key] }
  }
  for (const key of ['url', 'video_url', 'image_url', 'download_url', 'output_url']) {
    if (typeof value[key] === 'string' && value[key]) return { url: value[key] }
  }
  for (const key of ['output', 'result', 'data', 'image', 'video', 'images', 'outputs']) {
    if (value[key] !== undefined) {
      const found = mediaFromValue(value[key], 0)
      if (found) return found
    }
  }
  return null
}

function mediaFromValue(value, depth = 0) {
  if (depth > 4 || value === null || value === undefined) return null
  if (typeof value === 'string') {
    if (value.startsWith('data:')) return { dataUrl: value }
    if (/^https?:\/\//i.test(value)) return { url: value }
    if (/^[A-Za-z0-9+/=\s]{80,}$/.test(value)) return { base64: value.replace(/\s+/g, '') }
    return null
  }
  if (Array.isArray(value)) {
    for (const entry of value) {
      const found = mediaFromValue(entry, depth + 1)
      if (found) return found
    }
    return null
  }
  if (isPlainObject(value)) return mediaFromObject(value)
  return null
}

export function extractMedia(json, provider) {
  if (provider?.responsePath) {
    const picked = pickPath(json, provider.responsePath)
    const found = mediaFromValue(picked)
    if (found) return found
  }
  return mediaFromValue(json)
}

function jobIdFrom(json) {
  const candidates = ['id', 'task_id', 'request_id', 'job_id', 'data[0].id', 'data.id', 'job.id', 'task.id']
  for (const path of candidates) {
    const value = pickPath(json, path)
    if (typeof value === 'string' && value) return value
  }
  return null
}

function mimeToExt(mime, kind) {
  const clean = String(mime ?? '').toLowerCase().split(';')[0].trim()
  const table = {
    'image/png': '.png',
    'image/jpeg': '.jpg',
    'image/jpg': '.jpg',
    'image/webp': '.webp',
    'image/gif': '.gif',
    'video/mp4': '.mp4',
    'video/webm': '.webm',
    'video/quicktime': '.mov',
  }
  return table[clean] ?? (kind === 'image' ? '.png' : '.mp4')
}

function guessMime(bytes, kind, contentType) {
  const type = String(contentType ?? '').split(';')[0].trim().toLowerCase()
  if (type.startsWith('image/') || type.startsWith('video/')) return type
  if (bytes.length >= 8 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return 'image/png'
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'image/jpeg'
  if (bytes.length >= 12 && String.fromCharCode(...bytes.slice(4, 8)) === 'ftyp') return 'video/mp4'
  return kind === 'image' ? 'image/png' : 'video/mp4'
}

function bytesFromBase64(base64) {
  const normalized = String(base64).replace(/^data:[^,]+,/, '').replace(/\s+/g, '')
  return new Uint8Array(Buffer.from(normalized, 'base64'))
}

async function downloadMedia(url, provider, kind, signal) {
  const maxBytes = kind === 'video' ? 300 * 1024 * 1024 : 30 * 1024 * 1024
  return withTimeout(signal, provider.timeoutMs, async (combinedSignal) => {
    const response = await fetch(url, { headers: { accept: '*/*' }, signal: combinedSignal })
    if (!response.ok) throw new Error(`media download failed: ${response.status} ${response.statusText}`)
    const declared = Number(response.headers.get('content-length') ?? '0')
    if (declared > maxBytes) throw new Error(`media is too large (${declared} bytes)`)
    // Read inside the deadline so a stalled body still times out.
    const buffer = new Uint8Array(await response.arrayBuffer())
    if (buffer.length > maxBytes) throw new Error(`media is too large (${buffer.length} bytes)`)
    return { bytes: buffer, mime: guessMime(buffer, kind, response.headers.get('content-type')) }
  })
}

function dataUrlMedia(dataUrl, kind) {
  const comma = dataUrl.indexOf(',')
  if (comma < 0) throw new Error('media data URL is malformed')
  const header = dataUrl.slice(5, comma)
  const mime = header.split(';')[0] || (kind === 'image' ? 'image/png' : 'video/mp4')
  return { bytes: bytesFromBase64(dataUrl.slice(comma + 1)), mime }
}

async function resolveMedia(found, provider, kind, signal) {
  if (found.url) {
    if (/^data:/i.test(found.url)) return dataUrlMedia(found.url, kind)
    return downloadMedia(found.url, provider, kind, signal)
  }
  if (found.dataUrl) return dataUrlMedia(found.dataUrl, kind)
  if (found.base64) {
    const bytes = bytesFromBase64(found.base64)
    return { bytes, mime: guessMime(bytes, kind, '') }
  }
  return null
}

function sleep(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new Error('aborted'))
      return
    }
    const timer = setTimeout(resolve, ms)
    const onAbort = () => {
      clearTimeout(timer)
      reject(new Error('aborted'))
    }
    signal?.addEventListener('abort', onAbort, { once: true })
  })
}

async function pollForMedia(provider, kind, firstJson, signal) {
  const id = jobIdFrom(firstJson)
  if (!id || !provider.pollPath) {
    throw new Error(
      `provider returned no direct media${id ? ` and job ${id} has no pollPath configured` : ''}: ${safeJson(firstJson).slice(0, 600)}`,
    )
  }
  const success = new Set(provider.successValues.split(',').map((entry) => entry.trim().toLowerCase()).filter(Boolean))
  const failure = new Set(provider.failureValues.split(',').map((entry) => entry.trim().toLowerCase()).filter(Boolean))
  const deadline = Date.now() + provider.pollMaxMs
  while (Date.now() < deadline) {
    await sleep(provider.pollIntervalMs, signal)
    const url = joinUrl(
      provider.baseURL,
      provider.pollPath.replaceAll('{id}', encodeURIComponent(id)).replaceAll('{task_id}', encodeURIComponent(id)),
    )
    const { json } = await httpJson(url, {
      method: 'GET',
      headers: providerHeaders(provider),
      timeoutMs: provider.timeoutMs,
      signal,
    })
    const status = String(pickPath(json, provider.statusField) ?? '').toLowerCase()
    const found = extractMedia(json, provider)
    if (found) {
      const media = await resolveMedia(found, provider, kind, signal)
      if (media) return media
    }
    if (success.has(status)) {
      const result = provider.resultField ? mediaFromValue(pickPath(json, provider.resultField)) : null
      const media = result ? await resolveMedia(result, provider, kind, signal) : null
      if (media) return media
      throw new Error(`job ${id} succeeded but no media was found: ${safeJson(json).slice(0, 600)}`)
    }
    if (failure.has(status)) {
      throw new Error(`job ${id} failed with status "${status}": ${safeJson(json).slice(0, 600)}`)
    }
  }
  throw new Error(`job ${id} did not finish within ${provider.pollMaxMs}ms`)
}

export async function callMediaProvider(provider, kind, prompt, options = {}) {
  requireModel(provider)
  const body = {
    model: provider.model,
    prompt,
    ...(options.size ? { size: options.size } : {}),
    ...(options.duration ? { duration: options.duration } : {}),
    ...(provider.responseFormat ? { response_format: provider.responseFormat } : {}),
    ...(provider.extraBody ?? {}),
  }
  const { json } = await httpJson(providerEndpoint(provider), {
    method: 'POST',
    headers: providerHeaders(provider, { 'content-type': 'application/json' }),
    body,
    timeoutMs: provider.timeoutMs,
    signal: options.signal,
  })
  let media = null
  const direct = extractMedia(json, provider)
  if (direct) media = await resolveMedia(direct, provider, kind, options.signal)
  if (!media) media = await pollForMedia(provider, kind, json, options.signal)
  if (!media) throw new Error(`provider returned no ${kind}: ${safeJson(json).slice(0, 600)}`)
  return media
}

export async function saveOutputFile(cwd, bytes, { kind, mime, filename } = {}) {
  if (!cwd) throw new Error('no working directory for the generated file')
  const dir = path.join(cwd, '.dsh-taskbridge', 'outputs')
  await fs.mkdir(dir, { recursive: true })
  const resolvedMime = mime || guessMime(bytes, kind, '')
  const ext = path.extname(String(filename ?? '')) || mimeToExt(resolvedMime, kind)
  let base = path.basename(String(filename ?? ''), path.extname(String(filename ?? '')))
  base = base.replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || `${kind}-${Date.now()}`
  let file = path.join(dir, `${base}${ext}`)
  let suffix = 2
  for (;;) {
    try {
      await fs.access(file)
      file = path.join(dir, `${base}-${suffix++}${ext}`)
    } catch {
      break
    }
  }
  await fs.writeFile(file, bytes)
  return { path: file, mime: resolvedMime, bytes: bytes.length }
}

/* ---------------------------------------------------------- advisor prompts -- */

function messageText(message) {
  if (!message || !Array.isArray(message.content)) return ''
  return message.content
    .filter((block) => block && block.type === 'text' && typeof block.text === 'string')
    .map((block) => block.text)
    .join('\n')
}

/**
 * Render the most recent conversation turns for the external advisor. Tool
 * results are included because the repeated failure is often a tool error.
 */
export function recentConversationText(session, limit = 10, maxChars = 12000) {
  let messages
  try {
    messages = session.deriveMessages()
  } catch {
    return ''
  }
  const selected = []
  for (const message of messages) {
    if (!['user', 'assistant', 'tool'].includes(message.role)) continue
    const text = messageText(message).trim()
    if (!text) continue
    selected.push(`${message.role.toUpperCase()}: ${text.slice(0, 1500)}`)
  }
  const text = selected.slice(-limit).join('\n\n')
  return text.length > maxChars ? text.slice(text.length - maxChars) : text
}

/** System+user messages for the external consultant call. */
export function buildAdvisorMessages({ plan, failure, conversation }) {
  const system = [
    'You are an external expert consultant helping another AI coding agent that is stuck.',
    'The agent runs inside DeepSeek Harness and can use shell, filesystem, web, and subagent tools.',
    'Give concrete, prioritized next actions. Prefer diagnosis over restating the error.',
    'Be concise (<= 400 words). If a command or file edit would unblock it, name it exactly.',
    'Do not claim to have executed anything yourself.',
  ].join(' ')
  const planText = plan ? renderPlanPrompt(plan) : '(no plan yet)'
  const user = [
    `The agent has made repeated failed attempts (${failure?.count ?? 0} consecutive failures).`,
    failure?.lastError ? `Last failure:\n${failure.lastError}` : '',
    `Current plan:\n${planText}`,
    conversation ? `Recent conversation (truncated):\n${conversation}` : '',
    'What is the most likely root cause, and what should the agent do next?',
  ]
    .filter(Boolean)
    .join('\n\n')
  return [
    { role: 'system', content: system },
    { role: 'user', content: user },
  ]
}

/**
 * Build the inbox notice that tells the model its advisor note is live. The
 * shape is the documented `UserMessage` contract: caller-owned id, user role,
 * text content, and the `user` source marker.
 *
 * @param count - number of consecutive failures the advisor observed.
 * @returns a plain-JSON user message accepted by `agent.inject()`/`followup()`.
 */
export function buildAdvisorNotice(count) {
  return {
    id: randomUUID(),
    role: 'user',
    content: [
      {
        type: 'text',
        text: `[TaskBridge external advisor] A configured external model reviewed ${Number(count) || 0} repeated failures. Its advice is in your system prompt now; use it to get unstuck, then update the plan.`,
      },
    ],
    source: { kind: 'user' },
  }
}
