# TaskBridge 任务桥

TaskBridge 是一个 DeepSeek Harness (DSH) 插件，把「持久任务计划书 / 实时进度列表」「自动智能体团队」和「外部文本、图像、视频模型 API 协作」放在同一个插件里。

> 本包不包含任何用户配置、API Key、审计日志或生成文件。所有运行时配置都保存在 DSH home 下，安装后由用户自行填写。

## 功能

### 实时任务计划书

- Agent 通过 `task_plan` 把多步任务拆成具体任务（标题、负责人、状态、进度、备注）。
- 计划由会话日志重建，保存在投影 `taskbridgePlan` 中；输入框上方会显示可折叠的实时计划卡片。
- `task_update` 让 Agent 持续更新进度，UI 立即刷新。
- 计划会同步写入当前工作区的 `.dsh-taskbridge/TASKBOARD.md`。
- 上下文压缩后，计划仍会注入后续请求；Agent 也可用 `task_plan { action: "status" }` 恢复进度，避免重做已完成任务。

### 外部模型 API 协作

在 **设置 → 任务桥** 中添加任意数量的接口：

| 类别 | 用途 |
| --- | --- |
| `text` | `external_model_consult` 手动咨询；连续错误达到阈值后自动外援 |
| `image` | `external_media_generate { kind: "image" }` 生成图片 |
| `video` | `external_media_generate { kind: "video" }` 生成视频，支持同步或异步轮询 |

每个接口可配置 Base URL、请求路径、模型、API Key、自定义请求头、附加请求体、超时、响应解析路径、异步任务轮询路径/状态字段/结果字段等。默认兼容 OpenAI Chat Completions / Images 风格的返回，也支持通过 `responsePath`、`extraBody` 和轮询字段适配私有协议。

**自动触发**：用户明确表达生成图片/视频意愿且对应类别有启用接口时，Agent 直接调用 `external_media_generate`，不先询问。  

**失败确认**：图片/视频第一次生成失败后，工具通过 `userQuestions.ask` 弹出“继续重试 / 停止”的选择；只有用户选择继续才重试一次，选择停止则返回 `cancelled`，不会自动重试。

### 自动智能体团队

用户明确要求“组队 / 多智能体 / 分工”时，Agent 先确保有 TaskBridge 计划，然后调用 `task_team`：

- `task_team { action: "create", maxAgents: 2-5 }` 按未完成任务分组，创建共享 Team 任务，并调用 Agent Teams 的 `spawnTeammate` 创建 worker；
- `integrator` 可选 `lead`（Lead 自己整合）或 `teammate`（额外创建 integrator）；
- `action: "status"` 查看成员与团队任务，`action: "stop"` 中断 teammate；
- 只有 Team Lead 能创建/停止，团队是扁平的，teammate 不能再创建团队。

### 连续错误自动外援

模型请求或工具连续失败达到 `autoConsult.afterErrors`（默认 3）后，插件会把错误、当前计划和最近对话发给第一个已启用的文本接口，并把建议注入下一轮系统提示。冷却时间默认 120 秒。未配置文本接口时不会触发。

## 工具

| 工具 | 说明 |
| --- | --- |
| `task_plan` | `create` / `replace` / `status` / `export` |
| `task_update` | 按任务 id 更新状态、负责人、进度、备注 |
| `external_model_consult` | 询问已配置的外部文本模型 |
| `external_media_generate` | 生成图像或视频；第一次失败后询问用户是否继续 |
| `task_team` | 创建/查看/停止自动智能体团队 |

## 安装

从 npm 安装：

```bash
dsh plugin add dsh-plugin-taskbridge
```

或通过 DSH 插件市场 / Plugin Manager 安装。安装后 Host/Client 会通过 HMR 生效；若页面未刷新，刷新一次 Web GUI。

插件 Host 半区需要 `webServer` 服务，因此适用于 Web / 桌面 Web profile；无 Web 的 headless profile 不会激活该插件。

## 配置位置

- 模型接口：`$DSH_HOME/taskbridge/models.json`（默认 `%USERPROFILE%\.dsh\taskbridge\models.json`）
- 协作审计：`$DSH_HOME/taskbridge/audit.jsonl`
- 计划文件：当前工作区 `.dsh-taskbridge/TASKBOARD.md`
- 生成媒体：当前工作区 `.dsh-taskbridge/outputs/`

API Key 只写入本机配置文件，不会回显到浏览器或工具结果。设置页只显示 `hasKey` 和末四位掩码。

## 配置 HTTP 端点

设置页通过以下同源端点读写配置：

- `GET /__taskbridge__/health`
- `GET /__taskbridge__/config`（脱敏，不含 API Key）
- `POST /__taskbridge__/config`（请求头 `x-taskbridge: 1`）

POST 中省略 `apiKey` 或留空会保留已保存的 Key；`clearKey: true` 才会删除。

## 安全与隐私

- 插件本身不包含用户配置、密钥或生成内容。
- 外部 API 只在用户显式配置并调用/触发时请求。
- API Key 以明文形式保存在本机 `$DSH_HOME` 配置文件中；请自行保护该目录。
- 插件不发送遥测数据。
- 子智能体不能修改主会话的计划；计划由主会话统一维护。

## 已知限制

- 计划工具只属于主会话，子智能体通过结果汇报进度。
- 文本接口需要是 OpenAI Chat Completions 兼容格式，或通过 `responsePath` 指定文本返回路径。
- 图像/视频接口默认支持 URL、base64 和异步轮询；复杂私有协议可通过高级字段适配。
- 自动团队依赖实验性 Agent Teams；只有 Lead 能创建 teammate，团队是扁平的，不能嵌套；每个 teammate 都会消耗模型调用。
- 图片/视频失败后的用户确认需要 `userQuestions` 服务；无法弹出问题的会话会拒绝自动重试。
- 生成文件不会自动清理。

## License

MIT
