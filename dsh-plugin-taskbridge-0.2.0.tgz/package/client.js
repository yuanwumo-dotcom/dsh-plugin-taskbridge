/**
 * TaskBridge browser half (plain-JS DSH client bundle).
 *
 * Two surfaces:
 *  1. A live, collapsible plan card above the composer, fed by the Host
 *     `taskbridgePlan` session projection.
 *  2. A TaskBridge settings section that edits the Host's local
 *     `models.json` through `/__taskbridge__/config`.
 *
 * No imports, no JSX: React arrives through the browser module table and
 * every element is built with React.createElement. Stored API keys never
 * reach this half; the Host answers with `hasKey`/`keyPreview` only.
 */
window.__ModuleLoader__.load({
  id: 'dsh-plugin-taskbridge',
  factory(require) {
    const React = require('react')
    const h = React.createElement

    /** Locale namespace owned by this plugin. */
    const NS = 'taskbridge'
    /** Session projection key registered by the Host half. */
    const PROJECTION_KEY = 'taskbridgePlan'
    /** Host configuration route (same origin). */
    const CONFIG_URL = '/__taskbridge__/config'
    /** Anti-CSRF hint header required by the Host on writes. */
    const CONFIG_HEADER = 'x-taskbridge'
    /** Provider categories supported by the Host. */
    const CATEGORIES = ['text', 'image', 'video']
    /** Provider fields sent back to the Host; `apiKey`/`clearKey` are added by the editor. */
    const PROVIDER_KEYS = [
      'id', 'name', 'category', 'protocol', 'baseURL', 'path', 'model',
      'headers', 'extraBody', 'enabled', 'timeoutMs', 'responsePath',
      'responseFormat', 'pollPath', 'pollIntervalMs', 'pollMaxMs',
      'statusField', 'resultField', 'successValues', 'failureValues', 'note',
    ]
    /** Stable per-instance ids for aria-controls. */
    let mountCounter = 0

    /* ------------------------------------------------------------ locale -- */

    const zh = {
      'plan.title': '任务计划',
      'plan.headerSummary': '{percent}% · {done}/{total} 已完成',
      'plan.expand': '展开计划',
      'plan.collapse': '收起计划',
      'plan.goal': '目标',
      'plan.progress': '总体进度 {percent}%',
      'plan.counts.completed': '{count} 已完成',
      'plan.counts.inProgress': '{count} 进行中',
      'plan.counts.pending': '{count} 待开始',
      'plan.counts.blocked': '{count} 受阻',
      'plan.empty': '计划中还没有任务。',
      'plan.untitledTask': '未命名任务',
      'plan.activity': '最近动态',
      'plan.noActivity': '暂无动态。',
      'plan.revision': '修订 {revision}',
      'plan.updatedAt': '更新于 {time}',
      'plan.assignee': '负责：{name}',
      'plan.taskProgress': '{percent}%',
      'plan.status.completed': '已完成',
      'plan.status.in_progress': '进行中',
      'plan.status.pending': '待开始',
      'plan.status.blocked': '受阻',
      'settings.nav': '任务桥',
      'settings.title': '任务桥',
      'settings.intro': '任务桥把当前任务计划显示在输入框上方，并管理供文本、图像、视频使用的外部模型接口。配置只保存在本机。',
      'settings.loading': '正在读取配置…',
      'settings.retry': '重试',
      'settings.reload': '重新读取',
      'settings.loadFailed': '读取配置失败：{message}',
      'settings.saveFailed': '保存失败：{message}',
      'settings.saved': '设置已保存。',
      'settings.configPath': '配置文件',
      'settings.auditPath': '审计日志',
      'settings.autoConsult.title': '自动外援',
      'settings.autoConsult.description': '当模型连续出错达到阈值时，自动把错误和当前计划发给一个已启用的文本接口，让外部模型给出下一步建议。',
      'settings.autoConsult.enabled': '连续出错时自动咨询外部文本模型',
      'settings.autoConsult.afterErrors': '触发前连续错误次数',
      'settings.autoConsult.afterErrorsHint': '1–20，默认 3。',
      'settings.autoConsult.cooldownSec': '冷却时间（秒）',
      'settings.autoConsult.cooldownSecHint': '0–3600，默认 120。',
      'settings.autoConsult.maxTokens': '回复最大 token 数',
      'settings.autoConsult.maxTokensHint': '100–8000，默认 1200。',
      'settings.save': '保存',
      'settings.saving': '保存中…',
      'settings.providers.title': 'AI 模型接口',
      'settings.providers.description': '按类别添加 OpenAI 兼容接口。文本接口用于手动或自动咨询，图像、视频接口用于生成媒体文件。密钥只写在本机配置文件中，不会回显。',
      'settings.category.text': '文本',
      'settings.category.image': '图像',
      'settings.category.video': '视频',
      'settings.addProvider': '添加{category}接口',
      'settings.noProviders': '尚未配置{category}接口。',
      'settings.provider.unnamed': '未命名接口',
      'settings.provider.enabled': '已启用',
      'settings.provider.disabled': '已停用',
      'settings.provider.noModel': '未设置模型',
      'settings.provider.keySet': '已保存密钥',
      'settings.provider.noKey': '未保存密钥',
      'settings.edit': '编辑',
      'settings.delete': '删除',
      'settings.deleteConfirm': '删除这个接口？',
      'settings.deleteYes': '确认删除',
      'settings.deleteNo': '取消',
      'settings.cancel': '取消',
      'settings.form.addTitle': '新增接口',
      'settings.form.editTitle': '编辑接口',
      'settings.form.name': '名称',
      'settings.form.namePlaceholder': '例如：DeepSeek 主接口',
      'settings.form.category': '类别',
      'settings.form.baseURL': '接口基础地址（baseURL）',
      'settings.form.baseURLPlaceholder': 'https://api.example.com/v1',
      'settings.form.path': '请求路径',
      'settings.form.pathHint': '留空使用类别默认值：文本 /chat/completions，图像 /images/generations，视频 /videos/generations。',
      'settings.form.model': '模型',
      'settings.form.modelPlaceholder': '例如：deepseek-chat',
      'settings.form.apiKey': 'API Key',
      'settings.form.apiKeyPlaceholder': '粘贴新的 API Key；留空保持不变',
      'settings.form.apiKeyStoredHint': '已保存密钥（{preview}）。留空保持不变。',
      'settings.form.apiKeyNewHint': '密钥只写入本机配置文件，之后不会回显。',
      'settings.form.clearKey': '删除已保存的密钥',
      'settings.form.headers': '请求头（JSON 对象）',
      'settings.form.headersHint': '可留空。例如 {"X-Org": "team"}。',
      'settings.form.extraBody': '附加请求体（JSON 对象）',
      'settings.form.extraBodyHint': '可留空，会合并进请求体。',
      'settings.form.enabled': '启用这个接口',
      'settings.form.timeoutMs': '请求超时（毫秒）',
      'settings.form.timeoutMsHint': '1000–600000，默认 60000。',
      'settings.form.advanced': '高级选项',
      'settings.form.responsePath': '响应内容路径',
      'settings.form.responsePathHint': '例如 choices[0].message.content；留空自动解析。',
      'settings.form.responseFormat': '图像/视频响应格式',
      'settings.form.responseFormatHint': '例如 b64_json 或 url；留空不发送。',
      'settings.form.pollPath': '任务轮询路径',
      'settings.form.pollPathHint': '异步任务用，可用 {id} 占位。',
      'settings.form.pollIntervalMs': '轮询间隔（毫秒）',
      'settings.form.pollIntervalMsHint': '500–60000，默认 3000。',
      'settings.form.pollMaxMs': '最长轮询时间（毫秒）',
      'settings.form.pollMaxMsHint': '5000–3600000，默认 300000。',
      'settings.form.statusField': '任务状态字段',
      'settings.form.statusFieldHint': '默认 status。',
      'settings.form.resultField': '任务结果字段',
      'settings.form.resultFieldHint': '留空时自动在响应中查找媒体。',
      'settings.form.successValues': '成功状态值',
      'settings.form.successValuesHint': '逗号分隔，默认 succeeded,completed,success,done。',
      'settings.form.failureValues': '失败状态值',
      'settings.form.failureValuesHint': '逗号分隔，默认 failed,error,cancelled,canceled。',
      'settings.form.note': '备注',
      'settings.form.noteHint': '给自己看的说明，可留空。',
      'settings.form.save': '保存接口',
      'settings.form.cancel': '取消',
      'settings.error.baseURLRequired': '请填写接口基础地址。',
      'settings.error.baseURLInvalid': '接口基础地址必须是有效的 http(s) URL。',
      'settings.error.headersJson': '请求头必须是 JSON 对象。',
      'settings.error.extraBodyJson': '附加请求体必须是 JSON 对象。',
      'settings.error.number': '{field}必须是 {min}–{max} 之间的整数。',
      'settings.error.afterErrors': '连续错误次数必须是 1–20 的整数。',
      'settings.error.cooldownSec': '冷却时间必须是 0–3600 的整数秒。',
      'settings.error.maxTokens': '最大 token 数必须是 100–8000 的整数。',
      'settings.error.invalidConfig': '配置数据不完整，请重新读取后再试。',
    }

    const en = {
      'plan.title': 'Task plan',
      'plan.headerSummary': '{percent}% · {done}/{total} done',
      'plan.expand': 'Expand plan',
      'plan.collapse': 'Collapse plan',
      'plan.goal': 'Goal',
      'plan.progress': 'Overall progress {percent}%',
      'plan.counts.completed': '{count} done',
      'plan.counts.inProgress': '{count} in progress',
      'plan.counts.pending': '{count} pending',
      'plan.counts.blocked': '{count} blocked',
      'plan.empty': 'No tasks in this plan yet.',
      'plan.untitledTask': 'Untitled task',
      'plan.activity': 'Latest activity',
      'plan.noActivity': 'No activity yet.',
      'plan.revision': 'Revision {revision}',
      'plan.updatedAt': 'Updated {time}',
      'plan.assignee': 'Owner: {name}',
      'plan.taskProgress': '{percent}%',
      'plan.status.completed': 'Done',
      'plan.status.in_progress': 'In progress',
      'plan.status.pending': 'Pending',
      'plan.status.blocked': 'Blocked',
      'settings.nav': 'TaskBridge',
      'settings.title': 'TaskBridge',
      'settings.intro': 'TaskBridge shows the current task plan above the composer and manages external model endpoints for text, image, and video work. Configuration stays on this machine.',
      'settings.loading': 'Loading configuration…',
      'settings.retry': 'Retry',
      'settings.reload': 'Reload',
      'settings.loadFailed': 'Could not load configuration: {message}',
      'settings.saveFailed': 'Could not save: {message}',
      'settings.saved': 'Settings saved.',
      'settings.configPath': 'Configuration file',
      'settings.auditPath': 'Audit log',
      'settings.autoConsult.title': 'Automatic second opinion',
      'settings.autoConsult.description': 'After a threshold of consecutive model errors, send the failure and current plan to an enabled text endpoint and use the external advice to get unstuck.',
      'settings.autoConsult.enabled': 'Consult an external text model after repeated failures',
      'settings.autoConsult.afterErrors': 'Consecutive errors before consulting',
      'settings.autoConsult.afterErrorsHint': '1–20, default 3.',
      'settings.autoConsult.cooldownSec': 'Cooldown (seconds)',
      'settings.autoConsult.cooldownSecHint': '0–3600, default 120.',
      'settings.autoConsult.maxTokens': 'Maximum reply tokens',
      'settings.autoConsult.maxTokensHint': '100–8000, default 1200.',
      'settings.save': 'Save',
      'settings.saving': 'Saving…',
      'settings.providers.title': 'AI model endpoints',
      'settings.providers.description': 'Add OpenAI-compatible endpoints by category. Text endpoints power manual or automatic consultation; image and video endpoints generate media files. Keys stay in the local configuration file and are never shown again.',
      'settings.category.text': 'Text',
      'settings.category.image': 'Image',
      'settings.category.video': 'Video',
      'settings.addProvider': 'Add {category} endpoint',
      'settings.noProviders': 'No {category} endpoint configured yet.',
      'settings.provider.unnamed': 'Unnamed endpoint',
      'settings.provider.enabled': 'Enabled',
      'settings.provider.disabled': 'Disabled',
      'settings.provider.noModel': 'No model',
      'settings.provider.keySet': 'Key stored',
      'settings.provider.noKey': 'No key',
      'settings.edit': 'Edit',
      'settings.delete': 'Delete',
      'settings.deleteConfirm': 'Delete this endpoint?',
      'settings.deleteYes': 'Delete',
      'settings.deleteNo': 'Cancel',
      'settings.cancel': 'Cancel',
      'settings.form.addTitle': 'New endpoint',
      'settings.form.editTitle': 'Edit endpoint',
      'settings.form.name': 'Name',
      'settings.form.namePlaceholder': 'e.g. Primary DeepSeek endpoint',
      'settings.form.category': 'Category',
      'settings.form.baseURL': 'Endpoint base URL',
      'settings.form.baseURLPlaceholder': 'https://api.example.com/v1',
      'settings.form.path': 'Request path',
      'settings.form.pathHint': 'Leave blank for the category default: text /chat/completions, image /images/generations, video /videos/generations.',
      'settings.form.model': 'Model',
      'settings.form.modelPlaceholder': 'e.g. deepseek-chat',
      'settings.form.apiKey': 'API Key',
      'settings.form.apiKeyPlaceholder': 'Paste a new API key; leave blank to keep the current one',
      'settings.form.apiKeyStoredHint': 'A key is stored ({preview}). Leave blank to keep it.',
      'settings.form.apiKeyNewHint': 'The key is written only to the local configuration file and never shown again.',
      'settings.form.clearKey': 'Delete the stored key',
      'settings.form.headers': 'Headers (JSON object)',
      'settings.form.headersHint': 'Optional, e.g. {"X-Org": "team"}.',
      'settings.form.extraBody': 'Extra request body (JSON object)',
      'settings.form.extraBodyHint': 'Optional; merged into the request body.',
      'settings.form.enabled': 'Enable this endpoint',
      'settings.form.timeoutMs': 'Request timeout (ms)',
      'settings.form.timeoutMsHint': '1000–600000, default 60000.',
      'settings.form.advanced': 'Advanced options',
      'settings.form.responsePath': 'Response content path',
      'settings.form.responsePathHint': 'e.g. choices[0].message.content; leave blank to auto-detect.',
      'settings.form.responseFormat': 'Image/video response format',
      'settings.form.responseFormatHint': 'e.g. b64_json or url; omitted when blank.',
      'settings.form.pollPath': 'Job polling path',
      'settings.form.pollPathHint': 'For asynchronous jobs; {id} is replaced with the job id.',
      'settings.form.pollIntervalMs': 'Poll interval (ms)',
      'settings.form.pollIntervalMsHint': '500–60000, default 3000.',
      'settings.form.pollMaxMs': 'Maximum polling time (ms)',
      'settings.form.pollMaxMsHint': '5000–3600000, default 300000.',
      'settings.form.statusField': 'Job status field',
      'settings.form.statusFieldHint': 'Default status.',
      'settings.form.resultField': 'Job result field',
      'settings.form.resultFieldHint': 'Leave blank to search the response for media automatically.',
      'settings.form.successValues': 'Success status values',
      'settings.form.successValuesHint': 'Comma separated; default succeeded,completed,success,done.',
      'settings.form.failureValues': 'Failure status values',
      'settings.form.failureValuesHint': 'Comma separated; default failed,error,cancelled,canceled.',
      'settings.form.note': 'Note',
      'settings.form.noteHint': 'Optional note for yourself.',
      'settings.form.save': 'Save endpoint',
      'settings.form.cancel': 'Cancel',
      'settings.error.baseURLRequired': 'Enter the endpoint base URL.',
      'settings.error.baseURLInvalid': 'The endpoint base URL must be a valid http(s) URL.',
      'settings.error.headersJson': 'Headers must be a JSON object.',
      'settings.error.extraBodyJson': 'The extra request body must be a JSON object.',
      'settings.error.number': '{field} must be an integer from {min} to {max}.',
      'settings.error.afterErrors': 'Consecutive errors must be an integer from 1 to 20.',
      'settings.error.cooldownSec': 'Cooldown must be an integer from 0 to 3600 seconds.',
      'settings.error.maxTokens': 'Maximum tokens must be an integer from 100 to 8000.',
      'settings.error.invalidConfig': 'The configuration response is incomplete; reload and try again.',
    }

    /* ------------------------------------------------------------- styles -- */

    const CSS = [
      /* plan dock */
      '.dsh-tb-dock{box-sizing:border-box;width:calc(100% - var(--dsh-composer-side-clearance,0px) - var(--dsh-composer-side-clearance,0px) - var(--dsh-composer-dock-inset,0px) - var(--dsh-composer-dock-inset,0px) - var(--dsh-composer-dock-inset,0px) - var(--dsh-composer-dock-inset,0px));max-width:calc(var(--dsh-composer-card-max-width,100%) - var(--dsh-composer-dock-inset,0px) - var(--dsh-composer-dock-inset,0px) - var(--dsh-composer-dock-inset,0px) - var(--dsh-composer-dock-inset,0px));flex:none;margin:0 auto;overflow:hidden;border:1px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-lg,12px);background:var(--dsw-alias-bg-layer-1);}',
      '.dsh-tb-dock-head{display:flex;align-items:center;gap:10px;width:100%;box-sizing:border-box;margin:0;padding:8px 12px;border:0;background:transparent;color:var(--dsw-alias-label-primary);font:inherit;font-size:13px;line-height:20px;text-align:left;cursor:pointer;}',
      '.dsh-tb-dock-head:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:-2px;}',
      '.dsh-tb-dock-lead{flex:none;display:grid;place-items:center;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-dock-title{flex:none;max-width:45%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px;font-weight:500;line-height:20px;}',
      '.dsh-tb-dock-summary{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-dock-chevron{flex:none;display:grid;place-items:center;color:var(--dsw-alias-label-secondary);transition:transform .15s ease;}',
      '.dsh-tb-dock[data-expanded="true"] .dsh-tb-dock-chevron{transform:rotate(180deg);}',
      '.dsh-tb-dock-body{display:flex;flex-direction:column;gap:8px;padding:0 12px 10px;}',
      '.dsh-tb-row{display:flex;align-items:center;gap:10px;}',
      '.dsh-tb-bar{flex:1;height:4px;border-radius:999px;overflow:hidden;background:var(--dsw-alias-border-l2);}',
      '.dsh-tb-bar-fill{display:block;height:100%;border-radius:inherit;background:var(--dsw-alias-brand-primary);transition:width .2s ease;}',
      '.dsh-tb-percent{flex:none;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);font-variant-numeric:tabular-nums;}',
      '.dsh-tb-counts{display:flex;flex-wrap:wrap;gap:4px 12px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-count{display:inline-flex;align-items:center;gap:5px;}',
      '.dsh-tb-dot{display:inline-block;flex:none;width:8px;height:8px;border-radius:50%;background:var(--dsw-alias-state-idle-primary);}',
      '.dsh-tb-dot[data-status="completed"]{background:var(--dsw-alias-state-success-primary);}',
      '.dsh-tb-dot[data-status="in_progress"]{background:var(--dsw-alias-brand-primary);}',
      '.dsh-tb-dot[data-status="blocked"]{background:var(--dsw-alias-state-error-primary);}',
      '.dsh-tb-goal{display:flex;gap:6px;margin:0;min-width:0;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-goal-text{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dsh-tb-tasks{display:flex;flex-direction:column;gap:6px;max-height:220px;margin:0;padding:0;overflow-y:auto;list-style:none;scrollbar-width:thin;}',
      '.dsh-tb-task{display:flex;flex-direction:column;gap:2px;min-width:0;padding:3px 0;}',
      '.dsh-tb-task-line{display:flex;align-items:center;gap:8px;min-width:0;}',
      '.dsh-tb-task-title{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px;line-height:20px;color:var(--dsw-alias-label-primary);}',
      '.dsh-tb-task-progress{flex:none;font-size:11px;line-height:18px;color:var(--dsw-alias-label-secondary);font-variant-numeric:tabular-nums;}',
      '.dsh-tb-task-meta{display:flex;align-items:center;gap:8px;min-width:0;padding-left:16px;font-size:11px;line-height:16px;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-chip{flex:none;padding:0 6px;border:1px solid var(--dsw-alias-border-l2);border-radius:999px;font-size:11px;line-height:16px;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-task-note{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dsh-tb-empty{margin:0;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-activity{display:flex;align-items:center;gap:6px;min-width:0;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-activity-text{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}',
      '.dsh-tb-activity-time{flex:none;font-variant-numeric:tabular-nums;}',
      '.dsh-tb-foot{display:flex;flex-wrap:wrap;justify-content:space-between;gap:4px 12px;font-size:11px;line-height:16px;color:var(--dsw-alias-label-secondary);}',
      /* settings page */
      '.dsh-tb-page{display:flex;flex-direction:column;box-sizing:border-box;padding:4px 0 28px;color:var(--dsw-alias-label-primary);}',
      '.dsh-tb-page-head{display:flex;flex-direction:column;gap:6px;padding:4px 0 16px;border-bottom:1px solid var(--dsw-alias-border-l2);}',
      '.dsh-tb-page-title{margin:0;font-size:16px;font-weight:500;line-height:24px;}',
      '.dsh-tb-hint{margin:0;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-path{display:flex;align-items:baseline;gap:8px;min-width:0;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-path-label{flex:none;}',
      '.dsh-tb-mono{font-family:var(--ds-font-family-code,ui-monospace,SFMono-Regular,Menlo,Consolas,monospace);font-size:12px;word-break:break-all;}',
      '.dsh-tb-section{display:flex;flex-direction:column;gap:12px;padding:18px 0;border-bottom:1px solid var(--dsw-alias-border-l2);}',
      '.dsh-tb-section:last-child{border-bottom:0;}',
      '.dsh-tb-section-head{display:flex;flex-direction:column;gap:4px;}',
      '.dsh-tb-section-title{margin:0;font-size:14px;font-weight:500;line-height:22px;}',
      '.dsh-tb-group{display:flex;flex-direction:column;gap:8px;}',
      '.dsh-tb-group-head{display:flex;align-items:center;gap:8px;}',
      '.dsh-tb-group-title{margin:0;font-size:13px;font-weight:500;line-height:20px;}',
      '.dsh-tb-group-head .dsh-tb-btn{margin-left:auto;}',
      '.dsh-tb-provider{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px solid var(--dsw-alias-border-l2);}',
      '.dsh-tb-provider:last-child{border-bottom:0;}',
      '.dsh-tb-provider-main{display:flex;flex:1;flex-direction:column;gap:3px;min-width:0;}',
      '.dsh-tb-provider-line{display:flex;flex-wrap:wrap;align-items:center;gap:8px;min-width:0;}',
      '.dsh-tb-provider-name{min-width:0;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px;font-weight:500;line-height:20px;}',
      '.dsh-tb-provider-meta{display:flex;flex-wrap:wrap;align-items:center;gap:8px;min-width:0;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-provider-actions{display:flex;flex:none;flex-wrap:wrap;align-items:center;gap:6px;}',
      '.dsh-tb-badge{display:inline-flex;align-items:center;gap:4px;flex:none;padding:0 7px;border:1px solid var(--dsw-alias-border-l2);border-radius:999px;font-size:11px;line-height:18px;color:var(--dsw-alias-label-secondary);white-space:nowrap;}',
      '.dsh-tb-badge-text{border-color:var(--dsw-alias-brand-primary);color:var(--dsw-alias-brand-primary);}',
      '.dsh-tb-badge-image{border-color:var(--dsw-alias-state-success-primary);color:var(--dsw-alias-state-success-primary);}',
      '.dsh-tb-badge-video{border-color:var(--dsw-alias-state-warn-primary);color:var(--dsw-alias-state-warn-primary);}',
      '.dsh-tb-badge-on{border-color:var(--dsw-alias-state-success-primary);color:var(--dsw-alias-state-success-primary);}',
      '.dsh-tb-badge-off{border-color:var(--dsw-alias-state-idle-primary);color:var(--dsw-alias-state-idle-primary);}',
      '.dsh-tb-form{display:flex;flex-direction:column;gap:12px;box-sizing:border-box;padding:12px 14px;border:1px solid var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-lg,12px);background:var(--dsw-alias-bg-layer-1);}',
      '.dsh-tb-form-head{display:flex;align-items:center;justify-content:space-between;gap:8px;}',
      '.dsh-tb-form-title{margin:0;font-size:13px;font-weight:500;line-height:20px;}',
      '.dsh-tb-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px 12px;}',
      '.dsh-tb-field{display:flex;flex-direction:column;gap:4px;min-width:0;}',
      '.dsh-tb-field-full{grid-column:1 / -1;}',
      '.dsh-tb-label{font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-input,.dsh-tb-select,.dsh-tb-textarea{box-sizing:border-box;width:100%;font:inherit;font-size:13px;line-height:20px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-base);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;padding:0 10px;height:32px;}',
      '.dsh-tb-textarea{height:auto;min-height:64px;padding:7px 10px;resize:vertical;font-family:var(--ds-font-family-code,ui-monospace,SFMono-Regular,Menlo,Consolas,monospace);font-size:12px;line-height:18px;}',
      '.dsh-tb-input:focus-visible,.dsh-tb-select:focus-visible,.dsh-tb-textarea:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:1px;}',
      '.dsh-tb-input:disabled,.dsh-tb-select:disabled,.dsh-tb-textarea:disabled{opacity:.55;}',
      '.dsh-tb-check{display:inline-flex;align-items:center;gap:8px;font-size:13px;line-height:20px;color:var(--dsw-alias-label-primary);cursor:pointer;}',
      '.dsh-tb-check input{margin:0;accent-color:var(--dsw-alias-brand-primary);}',
      '.dsh-tb-actions{display:flex;flex-wrap:wrap;align-items:center;gap:8px;}',
      '.dsh-tb-btn{box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;gap:4px;height:30px;padding:0 12px;font:inherit;font-size:13px;line-height:20px;color:var(--dsw-alias-label-primary);background:transparent;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;cursor:pointer;white-space:nowrap;}',
      '.dsh-tb-btn:hover:not(:disabled){background:var(--dsw-alias-bg-layer-2);}',
      '.dsh-tb-btn:focus-visible{outline:2px solid var(--dsw-alias-brand-primary);outline-offset:1px;}',
      '.dsh-tb-btn:disabled{opacity:.5;cursor:default;}',
      '.dsh-tb-btn-primary{border-color:var(--dsw-alias-brand-primary);color:var(--dsw-alias-brand-primary);}',
      '.dsh-tb-btn-danger{border-color:var(--dsw-alias-state-error-primary);color:var(--dsw-alias-state-error-primary);}',
      '.dsh-tb-error{margin:0;font-size:12px;line-height:18px;color:var(--dsw-alias-state-error-primary);}',
      '.dsh-tb-alert{box-sizing:border-box;margin:10px 0 0;padding:8px 10px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;font-size:12px;line-height:18px;}',
      '.dsh-tb-alert-ok{border-color:var(--dsw-alias-state-success-primary);color:var(--dsw-alias-state-success-primary);}',
      '.dsh-tb-alert-error{border-color:var(--dsw-alias-state-error-primary);color:var(--dsw-alias-state-error-primary);}',
      '.dsh-tb-details{padding-top:10px;border-top:1px solid var(--dsw-alias-border-l2);}',
      '.dsh-tb-details > summary{cursor:pointer;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);user-select:none;}',
      '.dsh-tb-details[open] > summary{margin-bottom:10px;}',
      '.dsh-tb-delete{display:flex;flex-wrap:wrap;align-items:center;gap:6px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);}',
      '.dsh-tb-progress-line{display:flex;align-items:center;gap:10px;}',
      '@media (max-width:560px){.dsh-tb-grid{grid-template-columns:minmax(0,1fr);}}',
      '@media (prefers-reduced-motion:reduce){.dsh-tb-dock-chevron,.dsh-tb-bar-fill{transition:none;}}',
    ].join('')

    /* ------------------------------------------------------------ helpers -- */

    function isObject(value) {
      return value !== null && typeof value === 'object' && !Array.isArray(value)
    }

    function textOf(value, fallback) {
      return typeof value === 'string' ? value : (typeof fallback === 'string' ? fallback : '')
    }

    function toInteger(value, fallback, min, max) {
      const number = typeof value === 'number' ? value : Number.parseInt(String(value === undefined || value === null ? '' : value), 10)
      if (!Number.isFinite(number)) return fallback
      return Math.min(max, Math.max(min, Math.trunc(number)))
    }

    function parseIntegerText(value) {
      const normalized = String(value === undefined || value === null ? '' : value).trim()
      if (normalized === '' || !/^-?\d+$/.test(normalized)) return null
      const number = Number(normalized)
      return Number.isSafeInteger(number) ? number : null
    }

    function parseJsonObject(value) {
      const normalized = String(value === undefined || value === null ? '' : value).trim()
      if (normalized === '') return { value: {} }
      let parsed
      try {
        parsed = JSON.parse(normalized)
      } catch (error) {
        return { error: true }
      }
      if (!isObject(parsed)) return { error: true }
      return { value: parsed }
    }

    function stringifyJson(value) {
      try {
        return JSON.stringify(isObject(value) ? value : {}, null, 2)
      } catch (error) {
        return '{}'
      }
    }

    function toDate(value) {
      if (typeof value === 'number' && Number.isFinite(value)) return new Date(value)
      if (typeof value === 'string' && value.trim() !== '') {
        const parsed = Date.parse(value)
        if (!Number.isNaN(parsed)) return new Date(parsed)
      }
      return null
    }

    function formatTime(value) {
      const date = toDate(value)
      if (date === null) return ''
      try {
        return date.toLocaleString()
      } catch (error) {
        return date.toISOString().replace('T', ' ').slice(0, 19)
      }
    }

    function messageOf(error) {
      const message = error && typeof error.message === 'string' ? error.message : String(error)
      return message.length > 400 ? message.slice(0, 400) : message
    }

    function statusOfTask(task) {
      const status = task && typeof task === 'object' ? task.status : ''
      return status === 'completed' || status === 'in_progress' || status === 'blocked' ? status : 'pending'
    }

    function progressOfTask(task) {
      const value = task && typeof task === 'object' ? task.progress : undefined
      if (typeof value === 'number' && Number.isFinite(value)) {
        return Math.min(100, Math.max(0, Math.round(value)))
      }
      return 0
    }

    function ChecklistIcon() {
      return h('svg', {
        viewBox: '0 0 16 16',
        width: 16,
        height: 16,
        'aria-hidden': 'true',
        focusable: 'false',
      },
      h('path', {
        fill: 'currentColor',
        d: 'M2 2.75h12v1.5H2zM2 7.25h8.5v1.5H2zM2 11.75h6v1.5H2z',
      }))
    }

    function ChevronIcon() {
      return h('svg', {
        viewBox: '0 0 16 16',
        width: 14,
        height: 14,
        'aria-hidden': 'true',
        focusable: 'false',
      },
      h('path', {
        fill: 'currentColor',
        d: 'M8 10.9 3.4 6.3l1.06-1.06L8 8.78l3.54-3.54L12.6 6.3z',
      }))
    }

    /* -------------------------------------------------------------- plan -- */

    /**
     * Render the live `taskbridgePlan` projection.
     * @param props - slot props: the framework `useProjection` reader and `t`.
     * @returns the collapsible plan card, or null while no plan exists.
     */
    function PlanDock(props) {
      const t = typeof props.t === 'function' ? props.t : function fallbackTranslate(key) { return key }
      const readProjection = props.useProjection
      const plan = typeof readProjection === 'function' ? readProjection(PROJECTION_KEY) : undefined
      const [expanded, setExpanded] = React.useState(true)
      const listIdRef = React.useRef(null)
      if (listIdRef.current === null) {
        mountCounter += 1
        listIdRef.current = 'dsh-taskbridge-tasks-' + String(mountCounter)
      }

      if (!plan || typeof plan !== 'object') return null

      const tasks = Array.isArray(plan.tasks) ? plan.tasks : []
      const counts = { completed: 0, in_progress: 0, pending: 0, blocked: 0 }
      let progressSum = 0
      for (let index = 0; index < tasks.length; index += 1) {
        const task = tasks[index]
        const status = statusOfTask(task)
        counts[status] += 1
        progressSum += progressOfTask(task)
      }
      const percent = tasks.length === 0 ? 0 : Math.round(progressSum / tasks.length)
      const title = textOf(plan.title) || t('plan.title')
      const goal = textOf(plan.goal)
      const revision = typeof plan.revision === 'number' && Number.isFinite(plan.revision) ? plan.revision : 0
      const updated = formatTime(plan.updatedAt)
      const activity = Array.isArray(plan.activity) && plan.activity.length > 0
        ? plan.activity[plan.activity.length - 1]
        : null
      const activityText = activity && typeof activity.text === 'string' && activity.text !== ''
        ? activity.text
        : t('plan.noActivity')
      const activityTime = activity ? formatTime(activity.at) : ''
      const listId = listIdRef.current
      const toggleLabel = expanded ? t('plan.collapse') : t('plan.expand')

      const countRows = [
        h('span', { className: 'dsh-tb-count', key: 'completed' },
          h('span', { className: 'dsh-tb-dot', 'data-status': 'completed', 'aria-hidden': 'true' }),
          t('plan.counts.completed', { count: counts.completed })),
        h('span', { className: 'dsh-tb-count', key: 'in_progress' },
          h('span', { className: 'dsh-tb-dot', 'data-status': 'in_progress', 'aria-hidden': 'true' }),
          t('plan.counts.inProgress', { count: counts.in_progress })),
        h('span', { className: 'dsh-tb-count', key: 'pending' },
          h('span', { className: 'dsh-tb-dot', 'data-status': 'pending', 'aria-hidden': 'true' }),
          t('plan.counts.pending', { count: counts.pending })),
        h('span', { className: 'dsh-tb-count', key: 'blocked' },
          h('span', { className: 'dsh-tb-dot', 'data-status': 'blocked', 'aria-hidden': 'true' }),
          t('plan.counts.blocked', { count: counts.blocked })),
      ]

      const taskRows = tasks.map(function renderTask(task, index) {
        const status = statusOfTask(task)
        const progress = progressOfTask(task)
        const taskTitle = textOf(task && task.title) || t('plan.untitledTask')
        const assignee = textOf(task && task.assignee)
        const notes = textOf(task && task.notes)
        const taskKey = textOf(task && task.id) + '-' + String(index)
        return h('li', { className: 'dsh-tb-task', key: taskKey, 'data-status': status },
          h('div', { className: 'dsh-tb-task-line' },
            h('span', {
              className: 'dsh-tb-dot',
              'data-status': status,
              role: 'img',
              'aria-label': t('plan.status.' + status),
            }),
            h('span', { className: 'dsh-tb-task-title', title: taskTitle }, taskTitle),
            h('span', { className: 'dsh-tb-task-progress' }, t('plan.taskProgress', { percent: progress }))),
          h('div', { className: 'dsh-tb-task-meta' },
            assignee !== '' ? h('span', { className: 'dsh-tb-chip' }, t('plan.assignee', { name: assignee })) : null,
            h('span', { className: 'dsh-tb-task-status' }, t('plan.status.' + status)),
            notes !== '' ? h('span', { className: 'dsh-tb-task-note', title: notes }, notes) : null))
      })

      return h('section', {
        className: 'dsh-tb-dock',
        'data-expanded': expanded ? 'true' : 'false',
        'data-taskbridge-dock': 'taskbridge-plan',
        'aria-label': t('plan.title'),
      },
      h('button', {
        type: 'button',
        className: 'dsh-tb-dock-head',
        'aria-expanded': expanded,
        'aria-controls': listId,
        title: toggleLabel,
        onClick: function onToggle() { setExpanded(function flip(value) { return !value }) },
      },
      h('span', { className: 'dsh-tb-dock-lead', 'aria-hidden': 'true' }, h(ChecklistIcon)),
      h('span', { className: 'dsh-tb-dock-title', title: title }, title),
      h('span', { className: 'dsh-tb-dock-summary' },
        t('plan.headerSummary', { percent: percent, done: counts.completed, total: tasks.length })),
      h('span', { className: 'dsh-tb-dock-chevron', 'aria-hidden': 'true' }, h(ChevronIcon))),
      expanded
        ? h('div', { className: 'dsh-tb-dock-body', id: listId },
          h('div', { className: 'dsh-tb-progress-line' },
            h('div', {
              className: 'dsh-tb-bar',
              role: 'progressbar',
              'aria-valuemin': 0,
              'aria-valuemax': 100,
              'aria-valuenow': percent,
              'aria-label': t('plan.progress', { percent: percent }),
            }, h('span', { className: 'dsh-tb-bar-fill', style: { width: String(percent) + '%' } })),
            h('span', { className: 'dsh-tb-percent' }, String(percent) + '%')),
          h('div', { className: 'dsh-tb-counts' }, countRows),
          goal !== ''
            ? h('p', { className: 'dsh-tb-goal' },
              h('span', { className: 'dsh-tb-chip' }, t('plan.goal')),
              h('span', { className: 'dsh-tb-goal-text', title: goal }, goal))
            : null,
          tasks.length === 0
            ? h('p', { className: 'dsh-tb-empty' }, t('plan.empty'))
            : h('ul', { className: 'dsh-tb-tasks' }, taskRows),
          h('div', { className: 'dsh-tb-activity' },
            h('span', { className: 'dsh-tb-chip' }, t('plan.activity')),
            h('span', { className: 'dsh-tb-activity-text', title: activityText }, activityText),
            activityTime !== '' ? h('span', { className: 'dsh-tb-activity-time' }, activityTime) : null),
          h('div', { className: 'dsh-tb-foot' },
            h('span', null, t('plan.revision', { revision: revision })),
            updated !== '' ? h('span', null, t('plan.updatedAt', { time: updated })) : null))
        : null)
    }

    /* ---------------------------------------------------------- settings -- */

    function normalizeAutoConsult(raw) {
      const auto = isObject(raw) ? raw : {}
      return {
        enabled: auto.enabled !== false,
        afterErrors: toInteger(auto.afterErrors, 3, 1, 20),
        cooldownSec: toInteger(auto.cooldownSec, 120, 0, 3600),
        maxTokens: toInteger(auto.maxTokens, 1200, 100, 8000),
      }
    }

    function normalizeProvider(raw, index) {
      const provider = isObject(raw) ? raw : {}
      const category = CATEGORIES.indexOf(provider.category) >= 0 ? provider.category : 'text'
      const id = textOf(provider.id)
      return {
        id: id === '' ? 'provider-' + String(index + 1) : id,
        name: textOf(provider.name),
        category: category,
        protocol: textOf(provider.protocol),
        baseURL: textOf(provider.baseURL),
        path: textOf(provider.path),
        model: textOf(provider.model),
        headers: isObject(provider.headers) ? provider.headers : {},
        extraBody: isObject(provider.extraBody) ? provider.extraBody : {},
        enabled: provider.enabled !== false,
        timeoutMs: toInteger(provider.timeoutMs, 60000, 1000, 600000),
        responsePath: textOf(provider.responsePath),
        responseFormat: textOf(provider.responseFormat),
        pollPath: textOf(provider.pollPath),
        pollIntervalMs: toInteger(provider.pollIntervalMs, 3000, 500, 60000),
        pollMaxMs: toInteger(provider.pollMaxMs, 300000, 5000, 3600000),
        statusField: textOf(provider.statusField) || 'status',
        resultField: textOf(provider.resultField),
        successValues: textOf(provider.successValues) || 'succeeded,completed,success,done',
        failureValues: textOf(provider.failureValues) || 'failed,error,cancelled,canceled',
        note: textOf(provider.note),
        hasKey: provider.hasKey === true,
        keyPreview: textOf(provider.keyPreview),
      }
    }

    function normalizeConfigData(raw) {
      const config = isObject(raw) ? raw : {}
      const providers = Array.isArray(config.providers)
        ? config.providers.filter(isObject).map(normalizeProvider)
        : []
      return {
        autoConsult: normalizeAutoConsult(config.autoConsult),
        providers: providers,
      }
    }

    function emptyDraft(category) {
      return {
        id: '',
        name: '',
        category: CATEGORIES.indexOf(category) >= 0 ? category : 'text',
        baseURL: '',
        path: '',
        model: '',
        apiKey: '',
        clearKey: false,
        headers: '{}',
        extraBody: '{}',
        enabled: true,
        timeoutMs: '60000',
        responsePath: '',
        responseFormat: '',
        pollPath: '',
        pollIntervalMs: '3000',
        pollMaxMs: '300000',
        statusField: 'status',
        resultField: '',
        successValues: 'succeeded,completed,success,done',
        failureValues: 'failed,error,cancelled,canceled',
        note: '',
      }
    }

    function draftFromProvider(provider) {
      return {
        id: provider.id,
        name: provider.name,
        category: provider.category,
        baseURL: provider.baseURL,
        path: provider.path,
        model: provider.model,
        apiKey: '',
        clearKey: false,
        headers: stringifyJson(provider.headers),
        extraBody: stringifyJson(provider.extraBody),
        enabled: provider.enabled,
        timeoutMs: String(provider.timeoutMs),
        responsePath: provider.responsePath,
        responseFormat: provider.responseFormat,
        pollPath: provider.pollPath,
        pollIntervalMs: String(provider.pollIntervalMs),
        pollMaxMs: String(provider.pollMaxMs),
        statusField: provider.statusField,
        resultField: provider.resultField,
        successValues: provider.successValues,
        failureValues: provider.failureValues,
        note: provider.note,
      }
    }

    function payloadProvider(provider) {
      const payload = {}
      for (let index = 0; index < PROVIDER_KEYS.length; index += 1) {
        const key = PROVIDER_KEYS[index]
        if (provider[key] !== undefined) payload[key] = provider[key]
      }
      return payload
    }

    function providerPayloads(config) {
      return config.providers.map(payloadProvider)
    }

    /**
     * Validate one editor draft and convert it into a Host provider payload.
     * @returns {provider} or {errorKey, errorParams}
     */
    function buildProviderPayload(draft, existing, t) {
      const baseURL = String(draft.baseURL || '').trim()
      if (baseURL === '') return { errorKey: 'settings.error.baseURLRequired' }
      let parsedUrl
      try {
        parsedUrl = new URL(baseURL)
      } catch (error) {
        return { errorKey: 'settings.error.baseURLInvalid' }
      }
      if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
        return { errorKey: 'settings.error.baseURLInvalid' }
      }
      const headers = parseJsonObject(draft.headers)
      if (headers.error) return { errorKey: 'settings.error.headersJson' }
      const extraBody = parseJsonObject(draft.extraBody)
      if (extraBody.error) return { errorKey: 'settings.error.extraBodyJson' }

      const timeoutMs = parseIntegerText(draft.timeoutMs)
      if (timeoutMs === null || timeoutMs < 1000 || timeoutMs > 600000) {
        return {
          errorKey: 'settings.error.number',
          errorParams: { field: t('settings.form.timeoutMs'), min: 1000, max: 600000 },
        }
      }
      const pollIntervalMs = parseIntegerText(draft.pollIntervalMs)
      if (pollIntervalMs === null || pollIntervalMs < 500 || pollIntervalMs > 60000) {
        return {
          errorKey: 'settings.error.number',
          errorParams: { field: t('settings.form.pollIntervalMs'), min: 500, max: 60000 },
        }
      }
      const pollMaxMs = parseIntegerText(draft.pollMaxMs)
      if (pollMaxMs === null || pollMaxMs < 5000 || pollMaxMs > 3600000) {
        return {
          errorKey: 'settings.error.number',
          errorParams: { field: t('settings.form.pollMaxMs'), min: 5000, max: 3600000 },
        }
      }

      const provider = existing ? payloadProvider(existing) : {}
      provider.name = String(draft.name || '').trim()
      provider.category = CATEGORIES.indexOf(draft.category) >= 0 ? draft.category : 'text'
      /* A category change invalidates the stored protocol; let the Host re-derive it. */
      if (!existing || existing.category !== provider.category) delete provider.protocol
      provider.baseURL = baseURL
      provider.path = String(draft.path || '').trim()
      provider.model = String(draft.model || '').trim()
      provider.headers = headers.value
      provider.extraBody = extraBody.value
      provider.enabled = draft.enabled !== false
      provider.timeoutMs = timeoutMs
      provider.responsePath = String(draft.responsePath || '').trim()
      provider.responseFormat = String(draft.responseFormat || '').trim()
      provider.pollPath = String(draft.pollPath || '').trim()
      provider.pollIntervalMs = pollIntervalMs
      provider.pollMaxMs = pollMaxMs
      provider.statusField = String(draft.statusField || '').trim() || 'status'
      provider.resultField = String(draft.resultField || '').trim()
      provider.successValues = String(draft.successValues || '').trim()
      provider.failureValues = String(draft.failureValues || '').trim()
      provider.note = String(draft.note || '').trim()

      if (draft.clearKey === true) {
        provider.clearKey = true
      } else {
        const apiKey = String(draft.apiKey || '').trim()
        if (apiKey !== '') provider.apiKey = apiKey
      }
      return { provider: provider }
    }

    /**
     * Validate the auto-consult draft.
     * @returns {value} or {errorKey}
     */
    function buildAutoConsultPayload(draft) {
      const afterErrors = parseIntegerText(draft.afterErrors)
      if (afterErrors === null || afterErrors < 1 || afterErrors > 20) {
        return { errorKey: 'settings.error.afterErrors' }
      }
      const cooldownSec = parseIntegerText(draft.cooldownSec)
      if (cooldownSec === null || cooldownSec < 0 || cooldownSec > 3600) {
        return { errorKey: 'settings.error.cooldownSec' }
      }
      const maxTokens = parseIntegerText(draft.maxTokens)
      if (maxTokens === null || maxTokens < 100 || maxTokens > 8000) {
        return { errorKey: 'settings.error.maxTokens' }
      }
      return {
        value: {
          enabled: draft.enabled === true,
          afterErrors: afterErrors,
          cooldownSec: cooldownSec,
          maxTokens: maxTokens,
        },
      }
    }

    async function readResponseJson(response) {
      let body = ''
      try {
        body = await response.text()
      } catch (error) {
        body = ''
      }
      let json = null
      if (body !== '') {
        try {
          json = JSON.parse(body)
        } catch (error) {
          json = null
        }
      }
      return { body: body, json: json }
    }

    function errorFromResponse(response, body, json) {
      if (json && typeof json.error === 'string' && json.error !== '') return json.error
      if (body !== '') return body.slice(0, 300)
      return 'HTTP ' + String(response.status) + ' ' + String(response.statusText || '')
    }

    async function fetchConfig(signal) {
      const response = await fetch(CONFIG_URL, {
        method: 'GET',
        credentials: 'same-origin',
        cache: 'no-store',
        signal: signal,
      })
      const parsed = await readResponseJson(response)
      if (!response.ok || !parsed.json || parsed.json.ok !== true) {
        throw new Error(errorFromResponse(response, parsed.body, parsed.json))
      }
      if (!isObject(parsed.json.config)) {
        throw new Error('invalid config response')
      }
      return {
        config: normalizeConfigData(parsed.json.config),
        configPath: textOf(parsed.json.configPath),
        auditPath: textOf(parsed.json.auditPath),
      }
    }

    async function postConfig(payload, signal) {
      const response = await fetch(CONFIG_URL, {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        signal: signal,
        headers: {
          'content-type': 'application/json',
          [CONFIG_HEADER]: '1',
        },
        body: JSON.stringify(payload),
      })
      const parsed = await readResponseJson(response)
      if (!response.ok || !parsed.json || parsed.json.ok !== true) {
        throw new Error(errorFromResponse(response, parsed.body, parsed.json))
      }
      if (!isObject(parsed.json.config)) {
        throw new Error('invalid config response')
      }
      return {
        config: normalizeConfigData(parsed.json.config),
        configPath: textOf(parsed.json.configPath),
      }
    }

    function EditorField(props) {
      const t = props.t
      const draft = props.draft
      const field = props.field
      const inputProps = {
        className: props.textarea ? 'dsh-tb-textarea' : 'dsh-tb-input',
        value: draft[field],
        placeholder: props.placeholder || '',
        disabled: props.disabled,
        onChange: function onInputChange(event) {
          props.onChange(field, event.target.value)
        },
      }
      if (props.textarea) {
        inputProps.rows = props.rows || 4
        inputProps.spellCheck = false
      } else {
        inputProps.type = props.type || 'text'
        inputProps.autoComplete = props.autoComplete || 'off'
        if (props.inputMode) inputProps.inputMode = props.inputMode
      }
      if (props.min !== undefined) inputProps.min = props.min
      if (props.max !== undefined) inputProps.max = props.max
      return h('label', { className: props.full ? 'dsh-tb-field dsh-tb-field-full' : 'dsh-tb-field' },
        h('span', { className: 'dsh-tb-label' }, props.label),
        props.textarea ? h('textarea', inputProps) : h('input', inputProps),
        props.hint ? h('span', { className: 'dsh-tb-hint' }, props.hint) : null)
    }

    /**
     * The add/edit provider form. Stateless except for local `details` expansion.
     * @param props - t, draft, existing provider (or null), error text, busy and actions.
     */
    function ProviderEditor(props) {
      const t = props.t
      const draft = props.draft
      const existing = props.existing
      const disabled = props.busy === true
      const onChange = function onChange(field, value) {
        props.onChange(field, value)
      }
      const title = existing ? t('settings.form.editTitle') : t('settings.form.addTitle')
      const apiKeyPlaceholder = existing !== null && existing !== undefined && existing.hasKey
        ? t('settings.form.apiKeyStoredHint', { preview: existing.keyPreview })
        : t('settings.form.apiKeyPlaceholder')
      const showClearKey = existing !== null && existing !== undefined && existing.hasKey

      return h('div', { className: 'dsh-tb-form' },
        h('div', { className: 'dsh-tb-form-head' },
          h('h4', { className: 'dsh-tb-form-title' }, title)),
        h('div', { className: 'dsh-tb-grid' },
          h(EditorField, {
            t: t, draft: draft, field: 'name', label: t('settings.form.name'),
            placeholder: t('settings.form.namePlaceholder'), disabled: disabled, onChange: onChange,
          }),
          h('label', { className: 'dsh-tb-field' },
            h('span', { className: 'dsh-tb-label' }, t('settings.form.category')),
            h('select', {
              className: 'dsh-tb-select',
              value: draft.category,
              disabled: disabled,
              onChange: function onCategoryChange(event) {
                onChange('category', event.target.value)
              },
            }, CATEGORIES.map(function renderOption(category) {
              return h('option', { key: category, value: category }, t('settings.category.' + category))
            }))),
          h(EditorField, {
            t: t, draft: draft, field: 'baseURL', label: t('settings.form.baseURL'),
            placeholder: t('settings.form.baseURLPlaceholder'), disabled: disabled,
            onChange: onChange, full: true, autoComplete: 'url',
          }),
          h(EditorField, {
            t: t, draft: draft, field: 'path', label: t('settings.form.path'),
            hint: t('settings.form.pathHint'), disabled: disabled, onChange: onChange,
            placeholder: '/chat/completions',
          }),
          h(EditorField, {
            t: t, draft: draft, field: 'model', label: t('settings.form.model'),
            placeholder: t('settings.form.modelPlaceholder'), disabled: disabled, onChange: onChange,
          }),
          h(EditorField, {
            t: t, draft: draft, field: 'apiKey', label: t('settings.form.apiKey'),
            placeholder: apiKeyPlaceholder, hint: t('settings.form.apiKeyNewHint'),
            disabled: disabled || draft.clearKey === true, onChange: onChange,
            full: true, type: 'password', autoComplete: 'new-password',
          }),
          showClearKey
            ? h('label', { className: 'dsh-tb-check dsh-tb-field-full' },
              h('input', {
                type: 'checkbox',
                checked: draft.clearKey === true,
                disabled: disabled,
                onChange: function onClearKeyChange(event) {
                  onChange('clearKey', event.target.checked)
                },
              }),
              t('settings.form.clearKey'))
            : null,
          h(EditorField, {
            t: t, draft: draft, field: 'headers', label: t('settings.form.headers'),
            hint: t('settings.form.headersHint'), disabled: disabled, onChange: onChange,
            textarea: true, rows: 2, full: true,
          }),
          h(EditorField, {
            t: t, draft: draft, field: 'extraBody', label: t('settings.form.extraBody'),
            hint: t('settings.form.extraBodyHint'), disabled: disabled, onChange: onChange,
            textarea: true, rows: 2, full: true,
          }),
          h(EditorField, {
            t: t, draft: draft, field: 'timeoutMs', label: t('settings.form.timeoutMs'),
            hint: t('settings.form.timeoutMsHint'), disabled: disabled, onChange: onChange,
            inputMode: 'numeric',
          }),
          h('label', { className: 'dsh-tb-check' },
            h('input', {
              type: 'checkbox',
              checked: draft.enabled !== false,
              disabled: disabled,
              onChange: function onEnabledChange(event) {
                onChange('enabled', event.target.checked)
              },
            }),
            t('settings.form.enabled'))),
        h('details', { className: 'dsh-tb-details' },
          h('summary', null, t('settings.form.advanced')),
          h('div', { className: 'dsh-tb-grid' },
            h(EditorField, {
              t: t, draft: draft, field: 'responsePath', label: t('settings.form.responsePath'),
              hint: t('settings.form.responsePathHint'), disabled: disabled, onChange: onChange,
              full: true,
            }),
            h(EditorField, {
              t: t, draft: draft, field: 'responseFormat', label: t('settings.form.responseFormat'),
              hint: t('settings.form.responseFormatHint'), disabled: disabled, onChange: onChange,
            }),
            h(EditorField, {
              t: t, draft: draft, field: 'pollPath', label: t('settings.form.pollPath'),
              hint: t('settings.form.pollPathHint'), disabled: disabled, onChange: onChange,
              full: true,
            }),
            h(EditorField, {
              t: t, draft: draft, field: 'pollIntervalMs', label: t('settings.form.pollIntervalMs'),
              hint: t('settings.form.pollIntervalMsHint'), disabled: disabled, onChange: onChange,
              inputMode: 'numeric',
            }),
            h(EditorField, {
              t: t, draft: draft, field: 'pollMaxMs', label: t('settings.form.pollMaxMs'),
              hint: t('settings.form.pollMaxMsHint'), disabled: disabled, onChange: onChange,
              inputMode: 'numeric',
            }),
            h(EditorField, {
              t: t, draft: draft, field: 'statusField', label: t('settings.form.statusField'),
              hint: t('settings.form.statusFieldHint'), disabled: disabled, onChange: onChange,
            }),
            h(EditorField, {
              t: t, draft: draft, field: 'resultField', label: t('settings.form.resultField'),
              hint: t('settings.form.resultFieldHint'), disabled: disabled, onChange: onChange,
            }),
            h(EditorField, {
              t: t, draft: draft, field: 'successValues', label: t('settings.form.successValues'),
              hint: t('settings.form.successValuesHint'), disabled: disabled, onChange: onChange,
            }),
            h(EditorField, {
              t: t, draft: draft, field: 'failureValues', label: t('settings.form.failureValues'),
              hint: t('settings.form.failureValuesHint'), disabled: disabled, onChange: onChange,
            }),
            h(EditorField, {
              t: t, draft: draft, field: 'note', label: t('settings.form.note'),
              hint: t('settings.form.noteHint'), disabled: disabled, onChange: onChange,
              full: true,
            }))),
        props.error ? h('p', { className: 'dsh-tb-error', role: 'alert' }, props.error) : null,
        h('div', { className: 'dsh-tb-actions' },
          h('button', {
            type: 'button',
            className: 'dsh-tb-btn dsh-tb-btn-primary',
            disabled: disabled,
            onClick: props.onSave,
          }, disabled ? t('settings.saving') : t('settings.form.save')),
          h('button', {
            type: 'button',
            className: 'dsh-tb-btn',
            disabled: disabled,
            onClick: props.onCancel,
          }, t('settings.form.cancel'))))
    }

    function providerDisplayName(provider, t) {
      return provider.name !== '' ? provider.name : t('settings.provider.unnamed')
    }

    function providerBadgeClass(category) {
      if (category === 'image') return 'dsh-tb-badge dsh-tb-badge-image'
      if (category === 'video') return 'dsh-tb-badge dsh-tb-badge-video'
      return 'dsh-tb-badge dsh-tb-badge-text'
    }

    /**
     * TaskBridge settings section.
     * @param props - slot props: `t` from the locale namespace and the owner `close`.
     */
    function SettingsPage(props) {
      const t = typeof props.t === 'function' ? props.t : function fallbackTranslate(key) { return key }
      const [phase, setPhase] = React.useState('loading')
      const [loadError, setLoadError] = React.useState(null)
      const [config, setConfig] = React.useState(null)
      const [configPath, setConfigPath] = React.useState('')
      const [auditPath, setAuditPath] = React.useState('')
      const [auto, setAuto] = React.useState(null)
      const [autoError, setAutoError] = React.useState(null)
      const [editor, setEditor] = React.useState(null)
      const [pendingDelete, setPendingDelete] = React.useState(null)
      const [busy, setBusy] = React.useState(null)
      const [notice, setNotice] = React.useState(null)
      const abortRef = React.useRef(null)

      const aborted = function aborted() {
        return abortRef.current === null || abortRef.current.signal.aborted
      }

      const applyLoaded = function applyLoaded(data) {
        setConfig(data.config)
        setConfigPath(data.configPath)
        if (typeof data.auditPath === 'string') setAuditPath(data.auditPath)
        setAuto({
          enabled: data.config.autoConsult.enabled,
          afterErrors: String(data.config.autoConsult.afterErrors),
          cooldownSec: String(data.config.autoConsult.cooldownSec),
          maxTokens: String(data.config.autoConsult.maxTokens),
        })
      }

      const loadData = async function loadData(signal) {
        setPhase('loading')
        setLoadError(null)
        try {
          const data = await fetchConfig(signal)
          if (signal && signal.aborted) return
          applyLoaded(data)
          setPhase('ready')
        } catch (error) {
          if (signal && signal.aborted) return
          setPhase('error')
          setLoadError(messageOf(error))
        }
      }

      React.useEffect(function mount() {
        const controller = new AbortController()
        abortRef.current = controller
        void loadData(controller.signal)
        return function unmount() {
          controller.abort()
          abortRef.current = null
        }
      }, [])

      React.useEffect(function clearNotice() {
        if (!notice || notice.kind !== 'ok') return undefined
        const timer = window.setTimeout(function expire() { setNotice(null) }, 3200)
        return function cleanup() { window.clearTimeout(timer) }
      }, [notice])

      const signal = function signal() {
        return abortRef.current === null ? undefined : abortRef.current.signal
      }

      const flashSaved = function flashSaved() {
        setNotice({ kind: 'ok', text: t('settings.saved') })
      }

      const reload = function reload() {
        setEditor(null)
        setPendingDelete(null)
        setNotice(null)
        setAutoError(null)
        if (abortRef.current !== null) void loadData(abortRef.current.signal)
      }

      const openNew = function openNew(category) {
        setNotice(null)
        setEditor({ id: null, draft: emptyDraft(category), error: null })
      }

      const openEdit = function openEdit(provider) {
        setNotice(null)
        setEditor({ id: provider.id, draft: draftFromProvider(provider), error: null })
      }

      const cancelEditor = function cancelEditor() {
        if (busy !== null) return
        setEditor(null)
      }

      const changeDraft = function changeDraft(field, value) {
        setEditor(function update(current) {
          if (current === null) return current
          const draft = Object.assign({}, current.draft)
          draft[field] = value
          return { id: current.id, draft: draft, error: null }
        })
      }

      const changeAuto = function changeAuto(field, value) {
        setAutoError(null)
        setAuto(function update(current) {
          const next = Object.assign({}, current)
          next[field] = value
          return next
        })
      }

      const saveEditor = async function saveEditor() {
        if (config === null || editor === null || busy !== null) return
        /* Track the edited endpoint by id: another row may be deleted meanwhile. */
        const index = editor.id === null
          ? -1
          : config.providers.findIndex(function sameId(provider) { return provider.id === editor.id })
        if (editor.id !== null && index < 0) {
          setEditor({ id: editor.id, draft: editor.draft, error: t('settings.error.invalidConfig') })
          return
        }
        const existing = index >= 0 ? config.providers[index] : null
        const built = buildProviderPayload(editor.draft, existing, t)
        if (built.errorKey) {
          setEditor({ id: editor.id, draft: editor.draft, error: t(built.errorKey, built.errorParams) })
          return
        }
        const providers = providerPayloads(config)
        if (index >= 0) providers[index] = built.provider
        else providers.push(built.provider)
        setBusy('provider')
        try {
          const result = await postConfig({ autoConsult: config.autoConsult, providers: providers }, signal())
          if (aborted()) return
          setConfig(result.config)
          if (result.configPath !== '') setConfigPath(result.configPath)
          setEditor(null)
          setBusy(null)
          flashSaved()
        } catch (error) {
          if (aborted()) return
          setBusy(null)
          setEditor(function keepError(current) {
            if (current === null) return current
            return { id: current.id, draft: current.draft, error: messageOf(error) }
          })
        }
      }

      const saveAuto = async function saveAuto() {
        if (config === null || busy !== null || auto === null) return
        const built = buildAutoConsultPayload(auto)
        if (built.errorKey) {
          setAutoError(t(built.errorKey))
          return
        }
        setAutoError(null)
        setBusy('auto')
        try {
          const result = await postConfig({
            autoConsult: built.value,
            providers: providerPayloads(config),
          }, signal())
          if (aborted()) return
          setConfig(result.config)
          if (result.configPath !== '') setConfigPath(result.configPath)
          setAuto({
            enabled: result.config.autoConsult.enabled,
            afterErrors: String(result.config.autoConsult.afterErrors),
            cooldownSec: String(result.config.autoConsult.cooldownSec),
            maxTokens: String(result.config.autoConsult.maxTokens),
          })
          setBusy(null)
          flashSaved()
        } catch (error) {
          if (aborted()) return
          setBusy(null)
          setAutoError(messageOf(error))
        }
      }

      const confirmDelete = function confirmDelete(provider) {
        setPendingDelete(provider.id)
      }

      const cancelDelete = function cancelDelete() {
        setPendingDelete(null)
      }

      const deleteProvider = async function deleteProvider(provider) {
        if (config === null || busy !== null) return
        setBusy('delete')
        try {
          const providers = config.providers
            .filter(function keep(other) { return other.id !== provider.id })
            .map(payloadProvider)
          const result = await postConfig({ autoConsult: config.autoConsult, providers: providers }, signal())
          if (aborted()) return
          setConfig(result.config)
          if (result.configPath !== '') setConfigPath(result.configPath)
          setPendingDelete(null)
          if (editor !== null && editor.id === provider.id) setEditor(null)
          setBusy(null)
          flashSaved()
        } catch (error) {
          if (aborted()) return
          setBusy(null)
          setPendingDelete(null)
          setNotice({ kind: 'error', text: t('settings.saveFailed', { message: messageOf(error) }) })
        }
      }

      /* ---- render helpers (all data already normalized) ---- */

      const renderProviderRow = function renderProviderRow(provider, index) {
        const deleting = pendingDelete === provider.id
        const enabledBadgeClass = provider.enabled ? 'dsh-tb-badge dsh-tb-badge-on' : 'dsh-tb-badge dsh-tb-badge-off'
        const endpoint = provider.baseURL + (provider.path !== '' ? provider.path : '')
        return h('div', { className: 'dsh-tb-provider', key: provider.id + '-' + String(index) },
          h('div', { className: 'dsh-tb-provider-main' },
            h('div', { className: 'dsh-tb-provider-line' },
              h('span', { className: 'dsh-tb-provider-name', title: providerDisplayName(provider, t) },
                providerDisplayName(provider, t)),
              h('span', { className: providerBadgeClass(provider.category) }, t('settings.category.' + provider.category)),
              h('span', { className: enabledBadgeClass },
                provider.enabled ? t('settings.provider.enabled') : t('settings.provider.disabled'))),
            h('div', { className: 'dsh-tb-provider-meta' },
              h('span', null, provider.model !== '' ? provider.model : t('settings.provider.noModel')),
              endpoint !== '' ? h('span', { className: 'dsh-tb-mono', title: endpoint }, endpoint) : null,
              h('span', { className: 'dsh-tb-mono' }, provider.id)),
            h('div', { className: 'dsh-tb-provider-meta' },
              h('span', null, provider.hasKey ? t('settings.provider.keySet') : t('settings.provider.noKey')),
              provider.hasKey && provider.keyPreview !== ''
                ? h('span', { className: 'dsh-tb-mono' }, provider.keyPreview)
                : null,
              provider.note !== '' ? h('span', { className: 'dsh-tb-task-note', title: provider.note }, provider.note) : null)),
          h('div', { className: 'dsh-tb-provider-actions' },
            deleting
              ? h('span', { className: 'dsh-tb-delete' },
                h('span', null, t('settings.deleteConfirm')),
                h('button', {
                  type: 'button',
                  className: 'dsh-tb-btn dsh-tb-btn-danger',
                  disabled: busy !== null,
                  onClick: function onDelete() { void deleteProvider(provider) },
                }, t('settings.deleteYes')),
                h('button', {
                  type: 'button',
                  className: 'dsh-tb-btn',
                  disabled: busy !== null,
                  onClick: cancelDelete,
                }, t('settings.deleteNo')))
              : h(React.Fragment, null,
                h('button', {
                  type: 'button',
                  className: 'dsh-tb-btn',
                  disabled: busy !== null,
                  onClick: function onEdit() { openEdit(provider) },
                }, t('settings.edit')),
                h('button', {
                  type: 'button',
                  className: 'dsh-tb-btn',
                  disabled: busy !== null,
                  onClick: function onAskDelete() { confirmDelete(provider) },
                }, t('settings.delete')))))
      }

      const renderGroup = function renderGroup(category) {
        const providers = config.providers.filter(function match(provider) {
          return provider.category === category
        })
        const categoryLabel = t('settings.category.' + category)
        const rows = providers.map(function render(provider, index) {
          return renderProviderRow(provider, index)
        })
        return h('div', { className: 'dsh-tb-group', key: category },
          h('div', { className: 'dsh-tb-group-head' },
            h('h4', { className: 'dsh-tb-group-title' }, categoryLabel),
            h('span', { className: providerBadgeClass(category) }, String(providers.length)),
            h('button', {
              type: 'button',
              className: 'dsh-tb-btn',
              disabled: busy !== null,
              onClick: function onAdd() { openNew(category) },
            }, t('settings.addProvider', { category: categoryLabel }))),
          providers.length === 0
            ? h('p', { className: 'dsh-tb-empty' }, t('settings.noProviders', { category: categoryLabel }))
            : h('div', null, rows))
      }

      /* ---- page body ---- */

      if (phase === 'loading') {
        return h('div', { className: 'dsh-tb-page', 'data-taskbridge-settings': 'taskbridge' },
          h('p', { className: 'dsh-tb-hint', role: 'status' }, t('settings.loading')))
      }

      if (phase === 'error' || config === null || auto === null) {
        return h('div', { className: 'dsh-tb-page', 'data-taskbridge-settings': 'taskbridge' },
          h('div', { className: 'dsh-tb-page-head' },
            h('h2', { className: 'dsh-tb-page-title' }, t('settings.title'))),
          h('div', { className: 'dsh-tb-section' },
            h('p', { className: 'dsh-tb-error', role: 'alert' },
              t('settings.loadFailed', { message: loadError !== null ? loadError : t('settings.error.invalidConfig') })),
            h('div', { className: 'dsh-tb-actions' },
              h('button', {
                type: 'button',
                className: 'dsh-tb-btn dsh-tb-btn-primary',
                onClick: reload,
              }, t('settings.retry')))))
      }

      const editorExisting = editor === null || editor.id === null
        ? null
        : config.providers.find(function sameId(provider) { return provider.id === editor.id }) || null
      const editorElement = editor === null
        ? null
        : h(ProviderEditor, {
          key: 'dsh-tb-provider-editor',
          t: t,
          draft: editor.draft,
          existing: editorExisting,
          error: editor.error,
          busy: busy !== null,
          onChange: changeDraft,
          onSave: function onSave() { void saveEditor() },
          onCancel: cancelEditor,
        })

      const autoSection = h('section', { className: 'dsh-tb-section', 'aria-label': t('settings.autoConsult.title') },
        h('div', { className: 'dsh-tb-section-head' },
          h('h3', { className: 'dsh-tb-section-title' }, t('settings.autoConsult.title')),
          h('p', { className: 'dsh-tb-hint' }, t('settings.autoConsult.description'))),
        h('label', { className: 'dsh-tb-check' },
          h('input', {
            type: 'checkbox',
            checked: auto.enabled === true,
            disabled: busy !== null,
            onChange: function onAutoEnabled(event) { changeAuto('enabled', event.target.checked) },
          }),
          t('settings.autoConsult.enabled')),
        h('div', { className: 'dsh-tb-grid' },
          h(EditorField, {
            key: 'afterErrors', t: t, draft: auto, field: 'afterErrors',
            label: t('settings.autoConsult.afterErrors'), hint: t('settings.autoConsult.afterErrorsHint'),
            disabled: busy !== null, onChange: changeAuto, inputMode: 'numeric',
          }),
          h(EditorField, {
            key: 'cooldownSec', t: t, draft: auto, field: 'cooldownSec',
            label: t('settings.autoConsult.cooldownSec'), hint: t('settings.autoConsult.cooldownSecHint'),
            disabled: busy !== null, onChange: changeAuto, inputMode: 'numeric',
          }),
          h(EditorField, {
            key: 'maxTokens', t: t, draft: auto, field: 'maxTokens',
            label: t('settings.autoConsult.maxTokens'), hint: t('settings.autoConsult.maxTokensHint'),
            disabled: busy !== null, onChange: changeAuto, inputMode: 'numeric',
          })),
        h('div', { className: 'dsh-tb-actions' },
          h('button', {
            type: 'button',
            className: 'dsh-tb-btn dsh-tb-btn-primary',
            disabled: busy !== null,
            onClick: function onSaveAuto() { void saveAuto() },
          }, busy === 'auto' ? t('settings.saving') : t('settings.save')),
          autoError !== null ? h('span', { className: 'dsh-tb-error', role: 'alert' }, autoError) : null))

      const providersSection = h('section', { className: 'dsh-tb-section', 'aria-label': t('settings.providers.title') },
        h('div', { className: 'dsh-tb-section-head' },
          h('h3', { className: 'dsh-tb-section-title' }, t('settings.providers.title')),
          h('p', { className: 'dsh-tb-hint' }, t('settings.providers.description'))),
        editorElement,
        CATEGORIES.map(renderGroup))

      return h('div', { className: 'dsh-tb-page', 'data-taskbridge-settings': 'taskbridge' },
        h('div', { className: 'dsh-tb-page-head' },
          h('h2', { className: 'dsh-tb-page-title' }, t('settings.title')),
          h('p', { className: 'dsh-tb-hint' }, t('settings.intro')),
          configPath !== ''
            ? h('div', { className: 'dsh-tb-path' },
              h('span', { className: 'dsh-tb-path-label' }, t('settings.configPath')),
              h('code', { className: 'dsh-tb-mono', title: configPath }, configPath))
            : null,
          auditPath !== ''
            ? h('div', { className: 'dsh-tb-path' },
              h('span', { className: 'dsh-tb-path-label' }, t('settings.auditPath')),
              h('code', { className: 'dsh-tb-mono', title: auditPath }, auditPath))
            : null,
          h('div', { className: 'dsh-tb-actions' },
            h('button', {
              type: 'button',
              className: 'dsh-tb-btn',
              disabled: busy !== null,
              onClick: reload,
            }, t('settings.reload')))),
        notice !== null
          ? h('div', {
            className: notice.kind === 'error' ? 'dsh-tb-alert dsh-tb-alert-error' : 'dsh-tb-alert dsh-tb-alert-ok',
            role: notice.kind === 'error' ? 'alert' : 'status',
            'aria-live': 'polite',
          }, notice.text)
          : null,
        autoSection,
        providersSection)
    }

    /* -------------------------------------------------------------- apply -- */

    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        const t = ctx.locale.bind(NS)

        ctx.effect(function registerLocale() {
          return ctx.locale.register(NS, { zh: zh, en: en })
        }, 'taskbridge: locale dictionaries')

        ctx.effect(function injectStyles() {
          if (typeof document === 'undefined') return function noop() {}
          const tag = document.createElement('style')
          tag.dataset.taskbridgeStyles = '1'
          tag.textContent = CSS
          document.head.appendChild(tag)
          return function removeStyles() {
            tag.remove()
          }
        }, 'taskbridge: stylesheet')

        ctx.slots.inject('conversation.input.dock', function registerPlanDock() {
          return ctx.slots.register({
            name: 'conversation.input.dock',
            id: 'taskbridge-plan',
            order: 5,
            locale: NS,
          }, PlanDock)
        })

        ctx.slots.inject('settings.section', function registerSettingsSection() {
          return ctx.slots.register({
            name: 'settings.section',
            id: 'taskbridge',
            order: 25,
            label: function settingsLabel() {
              return t('settings.nav')
            },
            locale: NS,
          }, SettingsPage)
        })
      },
    }
  },
})
