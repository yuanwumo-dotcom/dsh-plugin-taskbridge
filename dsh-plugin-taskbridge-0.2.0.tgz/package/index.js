/**
 * TaskBridge host half.
 *
 * Two capabilities:
 *  1. A log-backed task plan (计划书) with an always-visible Client projection
 *     and a prompt section that restores progress after compaction.
 *  2. A user-configured external-model roster (text / image / video), tools to
 *     consult or generate media, and an automatic advisor after repeated errors.
 *
 * The host half deliberately imports only Node built-ins and ./core.js. It is a
 * persistent profile bundle installed by the Harness plugin manager.
 */
import path from 'node:path'
import {
  CONSULT_TOOL,
  MEDIA_TOOL,
  PLAN_TOOL,
  PROJECTION_KEY,
  PASSTHROUGH_SCHEMA,
  PROJECTION_STATE_SCHEMA,
  TASK_STATUSES,
  UPDATE_TOOL,
  appendAudit,
  applyProjectionEvent,
  applyTaskUpdates,
  assertPlanInput,
  auditPath,
  buildAdvisorMessages,
  buildAdvisorNotice,
  buildPlan,
  callMediaProvider,
  callTextProvider,
  configPath,
  initProjectionState,
  normalizeConfig,
  pickProvider,
  planFromProjectionState,
  planProgress,
  readConfig,
  recentConversationText,
  renderPlanMarkdown,
  renderPlanPrompt,
  sanitizeConfigForClient,
  saveOutputFile,
  taskStatusCounts,
  writeConfig,
  writePlanFile,
} from './core.js'

export const name = 'taskbridge'
export const inject = ['agents', 'sessionProjections', 'systemPrompt', 'tools', 'webServer']

/**
 * Route table path. The webserver's prefix matcher compares
 * `pathname === prefix || pathname.startsWith(prefix + '/')`, so the
 * registered prefix must NOT carry a trailing slash or no endpoint matches.
 */
const ROUTE_BASE = '/__taskbridge__'
const CONFIG_PATH = `${ROUTE_BASE}/config`
const HEALTH_PATH = `${ROUTE_BASE}/health`
const CONFIG_HEADER = 'x-taskbridge'

const PLANNER_POLICY = `## TaskBridge persistent plan
You own a live task plan that the user sees above the composer. It is backed by the session log, so it survives compaction.
- For any task with 2+ real steps, call task_plan with action "create" before substantive work. Include a title, the goal, and 3-10 concrete tasks with an assignee and status; a plan needs at least one task. If a plan already exists, create reuses it; do not create a second plan.
- Keep the list current: after starting, blocking, reassigning, or completing a meaningful step, call task_update with the affected task ids and progress. The user is watching this list.
- The plan is injected into your system prompt on every step. If you lose track after compaction, call task_plan with action "status"; continue from the listed progress instead of restarting completed work.
- Use action "replace" only when the user explicitly changes the goal. Use action "export" to rewrite the workspace plan file.
- When finished, mark every finished task completed and leave the plan visible as the work record.`

const MEDIA_POLICY = `## TaskBridge automatic media
- When the user clearly asks to create an image, picture, photo, illustration, or video (including "画一张", "生成图片", "生成视频"), and a matching enabled provider exists, call external_media_generate immediately in the same turn. Do not ask for permission first.
- Use the user's description as the prompt. Pass size or duration only when the user asked for it.
- If no provider of that category is enabled, tell the user which category to configure; never pretend a file was generated.
- If media generation fails, the tool itself asks the user whether to continue. Never retry automatically. Follow the tool result: a cancelled result means stop; otherwise use the returned file.
- Media generation must be confirmed by the user after a failure; do not work around that gate.`

const TEAM_POLICY = `## TaskBridge automatic team
- When the user explicitly asks to split work across multiple agents, create a team, or says "组队/多智能体/分工", ensure a TaskBridge plan exists (create it first if needed), then call task_team with action "create" and a bounded maxAgents (normally 2-5).
- Keep the Lead as integrator unless the user explicitly asks for an integrator teammate. Team members share the working directory; assign non-overlapping work and review their output.
- Do not create a team for a trivial task. After creation, record actual worker names in the plan with task_update when possible, and monitor with task_team status.
- A teammate cannot create another team; only the Lead can.`

const TEAM_TOOL = 'task_team'

/* --------------------------------------------------------------- utilities -- */

function textBlock(text) {
  return { type: 'text', text: String(text) }
}

function output(render) {
  // The enforced JSON-Schema subset accepts an object root with
  // additionalProperties; `properties` may be omitted for an open object.
  return { schema: { type: 'object', additionalProperties: true }, render }
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}

/** A subagent session must not own the user-facing plan or the advisor budget. */
function isDelegatedAgent(agent) {
  const header = agent?.session?.header
  if (!header) return false
  if (header.origin === 'subagent') return true
  return typeof header.delegationDepth === 'number' && header.delegationDepth > 0
}

function requireAgent(exec) {
  if (!exec?.agent?.session) throw new Error('this tool requires an owning agent session')
  return exec.agent
}

function requireTopLevelAgent(exec) {
  const agent = requireAgent(exec)
  if (isDelegatedAgent(agent)) {
    throw new Error(
      'the TaskBridge plan belongs to the top-level session; a subagent must report progress through its own result instead',
    )
  }
  return agent
}

/**
 * Resolve the session's effective working directory. The optional
 * `workingDirectory` service is authoritative; the immutable session header is
 * the fallback. Returns undefined rather than guessing `process.cwd()`: the
 * host's cwd is the installation directory, not the user's project.
 */
function cwdOf(ctx, agent) {
  const session = agent?.session
  if (!session) return undefined
  try {
    const service = typeof ctx.get === 'function' ? ctx.get('workingDirectory') : undefined
    const dir = service?.get?.(session)
    if (typeof dir === 'string' && dir.trim() !== '') return dir
  } catch {
    /* The optional service may be absent or not ready; fall through. */
  }
  const header = session.header?.cwd
  return typeof header === 'string' && header.trim() !== '' ? header : undefined
}

function relativePath(cwd, absolute) {
  if (!absolute || !cwd) return null
  try {
    const relative = path.relative(cwd, absolute)
    return relative && !relative.startsWith('..') ? relative : absolute
  } catch {
    return absolute
  }
}

async function safeWritePlan(ctx, plan, agent) {
  const cwd = cwdOf(ctx, agent)
  if (!cwd) {
    return { filePath: null, warning: 'no session working directory; the workspace plan file was skipped' }
  }
  try {
    const file = await writePlanFile(plan, cwd)
    return { filePath: relativePath(cwd, file), warning: null }
  } catch (error) {
    return {
      filePath: null,
      warning: `plan file was not written: ${error instanceof Error ? error.message : String(error)}`,
    }
  }
}

function statusGlyph(status) {
  switch (status) {
    case 'completed': return '[x]'
    case 'in_progress': return '[>]'
    case 'blocked': return '[!]'
    default: return '[ ]'
  }
}

function renderChecklist(plan, extra = '') {
  if (!plan) return 'No task plan exists yet.'
  const counts = taskStatusCounts(plan)
  const lines = [
    `${plan.title} — ${planProgress(plan)}% (${counts.completed}/${counts.total} completed)`,
    ...(plan.goal ? [`Goal: ${plan.goal}`] : []),
    ...(plan.tasks ?? []).map(
      (task) =>
        `${statusGlyph(task.status)} [${task.id}] ${task.title} · ${task.assignee} · ${task.status} · ${task.progress}%${task.notes ? ` — ${task.notes}` : ''}`,
    ),
  ]
  if (extra) lines.push(extra)
  return lines.join('\n')
}

function planPayload(plan, message, filePath, warning) {
  return {
    message,
    plan,
    counts: plan ? taskStatusCounts(plan) : null,
    progress: plan ? planProgress(plan) : 0,
    filePath: filePath ?? null,
    warning: warning ?? null,
  }
}

/* ------------------------------------------------------------------ tools -- */

function planTool(ctx) {
  return {
    name: PLAN_TOOL,
    description:
      'Create, read, replace, or export the persistent TaskBridge plan (计划书) for this session. The user sees the plan live above the composer. Use action "create" before multi-step work with at least one task; if a plan already exists, create returns it unchanged. Use action "status" to recover progress after compaction, and "replace" only when the goal changed.',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        action: {
          type: 'string',
          enum: ['create', 'replace', 'status', 'export'],
          description:
            'create (first plan, reuses an existing one) | replace (explicit goal change) | status (read current plan) | export (rewrite the workspace plan file)',
        },
        plan: {
          type: 'object',
          additionalProperties: false,
          description: 'The complete plan for create/replace; tasks is required and must hold at least one task.',
          properties: {
            title: { type: 'string', description: 'Plan title' },
            goal: { type: 'string', description: 'The user-facing objective' },
            notes: { type: 'string', description: 'Optional constraints or decisions' },
            tasks: {
              type: 'array',
              description: 'Concrete tasks, 3-10 recommended',
              items: {
                type: 'object',
                additionalProperties: false,
                properties: {
                  id: { type: 'string', description: 'Optional stable id (T1, T2, ...); generated when omitted' },
                  title: { type: 'string', description: 'What this task delivers' },
                  assignee: { type: 'string', description: 'Who owns it (DeepSeek, a subagent name, or the user)' },
                  status: { type: 'string', enum: [...TASK_STATUSES], description: 'pending | in_progress | completed | blocked' },
                  progress: { type: 'number', description: '0-100; derived from status when omitted' },
                  notes: { type: 'string', description: 'Short current note' },
                },
                required: ['title'],
              },
            },
          },
          required: ['tasks'],
        },
      },
      required: ['action'],
    },
    output: output((args, value) => [textBlock(renderChecklist(value.plan, value.warning ?? ''))]),
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      const agent = requireTopLevelAgent(exec)
      const session = agent.session
      const state = ctx.sessionProjections.stateOf(session, PROJECTION_KEY)
      const current = planFromProjectionState(state)
      const action = String(args.action ?? '')
      if (action === 'status') {
        return planPayload(current, current ? 'Current TaskBridge plan.' : 'No TaskBridge plan exists yet.')
      }
      if (action === 'export') {
        if (!current) throw new Error('No plan exists yet. Call action "create" first.')
        const written = await safeWritePlan(ctx, current, agent)
        return planPayload(
          current,
          written.warning ? 'Plan exported with a warning.' : 'Plan file rewritten.',
          written.filePath,
          written.warning,
        )
      }
      if (action !== 'create' && action !== 'replace') {
        throw new Error('action must be one of create, replace, status, export')
      }
      if (action === 'create' && current) {
        const written = await safeWritePlan(ctx, current, agent)
        return planPayload(
          current,
          'A plan already exists; it was reused unchanged. Call task_update to advance it, or use action "replace" only if the goal changed.',
          written.filePath,
          written.warning,
        )
      }
      assertPlanInput(args.plan)
      const plan = action === 'create' ? buildPlan(args.plan, null) : buildPlan(args.plan, current)
      const written = await safeWritePlan(ctx, plan, agent)
      return planPayload(
        plan,
        action === 'create' ? 'TaskBridge plan created.' : 'TaskBridge plan replaced.',
        written.filePath,
        written.warning,
      )
    },
  }
}

function updateTool(ctx) {
  return {
    name: UPDATE_TOOL,
    description:
      'Update tasks in the current TaskBridge plan by id. Send only the fields that changed. Keep statuses, assignees, progress, and short notes current — this live list and the post-compaction recovery both read it.',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        updates: {
          type: 'array',
          description: 'One entry per task to update',
          items: {
            type: 'object',
            additionalProperties: false,
            properties: {
              id: { type: 'string', description: 'Task id from the plan, for example T1' },
              status: { type: 'string', enum: [...TASK_STATUSES], description: 'pending | in_progress | completed | blocked' },
              progress: { type: 'number', description: '0-100' },
              assignee: { type: 'string', description: 'Owner' },
              title: { type: 'string', description: 'Corrected title' },
              notes: { type: 'string', description: 'Short current note (replaces the previous note)' },
              note: { type: 'string', description: 'Optional activity-log sentence for this update' },
            },
            required: ['id'],
          },
        },
      },
      required: ['updates'],
    },
    output: output((args, value) => [textBlock(renderChecklist(value.plan, value.message))]),
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      const agent = requireTopLevelAgent(exec)
      const state = ctx.sessionProjections.stateOf(agent.session, PROJECTION_KEY)
      const current = planFromProjectionState(state)
      if (!current) throw new Error('No TaskBridge plan exists yet. Call task_plan with action "create" first.')
      if (!Array.isArray(args.updates) || args.updates.length === 0) {
        throw new Error('updates must be a non-empty array of { id, ... } entries')
      }
      const next = applyTaskUpdates(current, args.updates)
      if (next === current) {
        throw new Error(
          `No task matched or changed. Current ids: ${current.tasks.map((task) => task.id).join(', ')}. Use task_plan action "status" to inspect the plan.`,
        )
      }
      const written = await safeWritePlan(ctx, next, agent)
      return {
        message: 'TaskBridge plan updated.',
        plan: next,
        counts: taskStatusCounts(next),
        progress: planProgress(next),
        filePath: written.filePath,
        warning: written.warning,
      }
    },
  }
}

/** Resolve the configured provider and raise an actionable error otherwise. */
function requireProvider(config, category, providerId) {
  const provider = pickProvider(config, category, providerId)
  if (provider) return provider
  if (providerId) {
    throw new Error(
      `No enabled ${category} provider with id "${providerId}" is configured. Ask the user to check Settings → TaskBridge → AI 模型接口.`,
    )
  }
  throw new Error(
    `No enabled ${category} provider is configured. Ask the user to add one in Settings → TaskBridge → AI 模型接口.`,
  )
}

function consultTool() {
  return {
    name: CONSULT_TOOL,
    description:
      'Ask one of the user-configured external TEXT model APIs for a second opinion when you are stuck. Include the concrete error and what you already tried. Only works when the user has enabled a text provider in Settings → TaskBridge.',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        question: { type: 'string', description: 'The concrete question or problem for the external model' },
        context: { type: 'string', description: 'Relevant error text, code, or attempted approaches' },
        providerId: { type: 'string', description: 'Optional configured text provider id; the first enabled text provider is used when omitted' },
      },
      required: ['question'],
    },
    output: output((args, value) => [
      textBlock(`External model (${value.provider} / ${value.model || 'default'}) says:\n\n${value.answer}`),
    ]),
    isConcurrencySafe: () => true,
    timeoutMs: 180000,
    async execute(args, exec) {
      const config = await readConfig()
      const provider = requireProvider(config, 'text', typeof args.providerId === 'string' ? args.providerId : undefined)
      const question = String(args.question ?? '').trim()
      if (!question) throw new Error('question must not be empty')
      const contextText = String(args.context ?? '').trim()
      const messages = [
        {
          role: 'system',
          content:
            'You are a concise external expert assisting a DeepSeek Harness coding agent. Diagnose the problem and give prioritized, concrete next actions. Do not claim to have executed anything.',
        },
        {
          role: 'user',
          content: contextText ? `${question}\n\nContext:\n${contextText}` : question,
        },
      ]
      const result = await callTextProvider(provider, messages, {
        maxTokens: config.autoConsult.maxTokens,
        temperature: 0.2,
        signal: exec.signal,
      })
      await appendAudit({ event: 'manual-consult', provider: provider.name, providerId: provider.id, ok: true })
      return {
        answer: result.text,
        provider: provider.name,
        providerId: provider.id,
        model: provider.model,
      }
    },
  }
}

function mediaKindLabel(kind) {
  return kind === 'video' ? '视频' : '图片'
}

function mediaErrorMessage(error) {
  return (error instanceof Error ? error.message : String(error)).slice(0, 500)
}

/**
 * A generation failure is a user decision, not an automatic retry. Ask the
 * exact live root agent's user-question answerer and only continue when the
 * answer is an explicit continue choice.
 */
async function askMediaContinue(ctx, exec, kind, provider, error) {
  const message = mediaErrorMessage(error)
  const service = typeof ctx.get === 'function' ? ctx.get('userQuestions') : undefined
  if (!service?.ask) {
    throw new Error(
      `第一次${mediaKindLabel(kind)}生成失败：${message}。当前会话无法弹出用户确认；请先询问用户是否继续，得到明确同意后再重试。`,
    )
  }
  let answer
  try {
    answer = await service.ask({
      agent: exec.agent,
      signal: exec.signal,
      questions: [
        {
          id: 'taskbridge-media-retry',
          header: '生成失败',
          question: `第一次${mediaKindLabel(kind)}生成失败：${message}。是否继续生成？`,
          options: [
            { label: '继续重试', description: '再调用一次同一个接口' },
            { label: '停止', description: '不再生成' },
          ],
        },
      ],
    })
  } catch (askError) {
    throw new Error(
      `第一次${mediaKindLabel(kind)}生成失败：${message}；无法让用户判断是否继续：${mediaErrorMessage(askError)}`,
    )
  }
  const item = Array.isArray(answer?.answers)
    ? answer.answers.find((entry) => entry?.id === 'taskbridge-media-retry')
    : undefined
  const selected = Array.isArray(item?.selected) ? item.selected : []
  const custom = typeof item?.custom === 'string' ? item.custom : ''
  const stop = selected.some((label) => /^(停止|取消|stop|cancel)/i.test(String(label))) ||
    /^(停止|取消|stop|cancel)/i.test(custom.trim())
  // No explicit answer is not consent to spend another generation attempt.
  if (selected.length === 0 && custom.trim() === '') return false
  return !stop
}

function mediaTool(ctx) {
  return {
    name: MEDIA_TOOL,
    description:
      'Generate an image or video with a user-configured IMAGE or VIDEO model API and save the result in the workspace. Call this immediately when the user asks for an image/video and a matching provider is enabled. If generation fails once, this tool asks the user whether to continue; never retry it manually. Only works when the user has enabled a provider of that category in Settings → TaskBridge.',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        kind: { type: 'string', enum: ['image', 'video'], description: 'Media category to generate' },
        prompt: { type: 'string', description: 'Generation prompt' },
        providerId: { type: 'string', description: 'Optional provider id; the first enabled provider in the category is used when omitted' },
        size: { type: 'string', description: 'Optional size, for example 1024x1024 or 1280x720' },
        duration: { type: 'number', description: 'Optional video duration in seconds' },
        filename: { type: 'string', description: 'Optional output base name' },
      },
      required: ['kind', 'prompt'],
    },
    output: output((args, value) => [
      textBlock(
        value?.cancelled
          ? `Generation stopped by user after the first ${value.kind} failure: ${value.error || 'unknown error'}`
          : `Generated ${value.kind} with ${value.provider} (${value.model || 'default'}).\nSaved: ${value.path}${value.relativePath ? `\nWorkspace path: ${value.relativePath}` : ''}\n${value.bytes} bytes · ${value.mime}`,
      ),
    ]),
    isConcurrencySafe: () => false,
    timeoutMs: 900000,
    async execute(args, exec) {
      const kind = String(args.kind ?? '')
      if (kind !== 'image' && kind !== 'video') throw new Error('kind must be image or video')
      const prompt = String(args.prompt ?? '').trim()
      if (!prompt) throw new Error('prompt must not be empty')
      const agent = requireTopLevelAgent(exec)
      const cwd = cwdOf(ctx, agent)
      if (!cwd) throw new Error('generating media requires a session working directory to save the file')
      const config = await readConfig()
      const provider = requireProvider(config, kind, typeof args.providerId === 'string' ? args.providerId : undefined)
      const options = {
        size: typeof args.size === 'string' ? args.size : undefined,
        duration: typeof args.duration === 'number' ? args.duration : undefined,
        signal: exec.signal,
      }
      let media
      try {
        media = await callMediaProvider(provider, kind, prompt, options)
      } catch (firstError) {
        if (exec.signal.aborted) throw firstError
        const firstMessage = mediaErrorMessage(firstError)
        await appendAudit({ event: 'media-generate', kind, provider: provider.name, providerId: provider.id, ok: false, error: firstMessage })
        const proceed = await askMediaContinue(ctx, exec, kind, provider, firstError)
        if (!proceed) {
          await appendAudit({ event: 'media-generate-cancelled', kind, provider: provider.name, providerId: provider.id })
          return {
            cancelled: true,
            kind,
            provider: provider.name,
            providerId: provider.id,
            model: provider.model,
            error: firstMessage,
          }
        }
        try {
          media = await callMediaProvider(provider, kind, prompt, options)
        } catch (secondError) {
          const secondMessage = mediaErrorMessage(secondError)
          await appendAudit({ event: 'media-generate', kind, provider: provider.name, providerId: provider.id, ok: false, error: secondMessage })
          throw new Error(
            `第一次${mediaKindLabel(kind)}生成失败：${firstMessage}；用户选择继续后再次失败：${secondMessage}`,
          )
        }
      }
      const saved = await saveOutputFile(cwd, media.bytes, {
        kind,
        mime: media.mime,
        filename: typeof args.filename === 'string' ? args.filename : undefined,
      })
      await appendAudit({ event: 'media-generate', kind, provider: provider.name, providerId: provider.id, ok: true, bytes: saved.bytes })
      return {
        kind,
        provider: provider.name,
        providerId: provider.id,
        model: provider.model,
        path: saved.path,
        relativePath: relativePath(cwd, saved.path),
        mime: saved.mime,
        bytes: saved.bytes,
      }
    },
  }
}

/* -------------------------------------------------------------- team tool -- */

function teamErrorMessage(error) {
  return (error instanceof Error ? error.message : String(error)).slice(0, 500)
}

function requireTeamService(ctx) {
  const service = typeof ctx.get === 'function' ? ctx.get('agentTeams') : undefined
  if (!service?.tryMembership || !service?.spawnTeammate || !service?.createTask) {
    throw new Error(
      'Agent Teams is not available in this profile. Enable the experimental Agent Teams packages before using task_team.',
    )
  }
  return service
}

function teamProvider() {
  // Team teammates are spawned through the subagent provider route, not the
  // Lead's chat provider. Agent Teams' tool config uses `spawn` for fresh
  // teammates (and `fork` for forked ones); use the fresh route here.
  return 'spawn'
}

function uniqueTeamName(base, used) {
  const normalized = String(base)
    .toLowerCase()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'worker'
  let name = normalized
  let suffix = 2
  while (used.has(name)) name = `${normalized}-${suffix++}`
  used.add(name)
  return name
}

function chunkTasks(tasks, count) {
  const size = Math.ceil(tasks.length / count)
  const groups = []
  for (let index = 0; index < count; index += 1) {
    const group = tasks.slice(index * size, (index + 1) * size)
    if (group.length > 0) groups.push(group)
  }
  return groups
}

function taskLine(task) {
  return `- [${task.id}] ${task.title} (assignee: ${task.assignee}, ${task.status}, ${task.progress}%)${task.notes ? ` — ${task.notes}` : ''}`
}

function workerPrompt(plan, name, tasks, teamTask) {
  return [
    `You are teammate "${name}" in a TaskBridge team led by "lead". Work in the shared workspace.`,
    `Plan: ${plan.title}`,
    plan.goal ? `Goal: ${plan.goal}` : '',
    'Your assigned plan tasks:',
    ...tasks.map(taskLine),
    `Team task id: ${teamTask.id}`,
    'First claim that team task with team_task_update { action: "claim", expected_revision: 1 }. Do the work, run the relevant checks, then complete it with action "complete".',
    'If you are blocked or need a decision, send_message to "lead" with the concrete blocker. Do not edit the TaskBridge plan (the Lead owns it). Do not create another team.',
    'Report changed files and tests in your final message.',
  ]
    .filter(Boolean)
    .join('\n')
}

function integratorPrompt(plan, workerTasks) {
  return [
    'You are the integrator teammate in a TaskBridge team led by "lead". Work in the shared workspace.',
    `Plan: ${plan.title}`,
    plan.goal ? `Goal: ${plan.goal}` : '',
    'Worker tasks:',
    ...workerTasks.map((task) => `- ${task.id}: ${task.subject}`),
    'Wait until every worker task is completed using team_task_list and wait_agent. Then inspect the workspace changes, run the relevant tests, fix integration defects, and send the Lead a concise report with files changed, tests run, and any remaining risk.',
    'Do not spawn teammates. Do not edit the TaskBridge plan; the Lead owns it.',
  ]
    .filter(Boolean)
    .join('\n')
}

function renderTeamResult(value) {
  const lines = []
  if (value.action === 'create') {
    lines.push(`Created TaskBridge team: ${value.members.length} member(s), ${value.workers.length} worker(s).`)
    for (const member of value.members) {
      lines.push(`- ${member.name} (${member.role}, ${member.status})${member.description ? ` — ${member.description}` : ''}`)
    }
    for (const worker of value.workers) {
      lines.push(`  ${worker.name} ← plan tasks ${worker.planTaskIds.join(', ')} (team task ${worker.teamTaskId})`)
    }
    if (value.integrator) lines.push(`Integrator: ${value.integrator}`)
    if (value.errors.length > 0) {
      lines.push('Errors:')
      for (const error of value.errors) lines.push(`- ${error.name}: ${error.error}`)
    }
    lines.push('Use list_agents/wait_agent and the team task tools to monitor; record worker assignments in the TaskBridge plan with task_update.')
  } else if (value.action === 'stop') {
    lines.push(`Interrupted ${value.stopped.length} teammate(s).`)
    for (const entry of value.stopped) lines.push(`- ${entry.name} (was ${entry.previousStatus})`)
    if (value.errors.length > 0) lines.push(`Errors: ${value.errors.map((error) => `${error.name}: ${error.error}`).join('; ')}`)
  } else {
    lines.push(`Team ${value.name} (${value.role}): ${value.members.length} member(s), ${value.tasks.length} task(s).`)
    for (const member of value.members) lines.push(`- ${member.name} (${member.role}, ${member.status})`)
    for (const task of value.tasks) {
      lines.push(`  ${task.id} [${task.status}] ${task.subject}${task.ownerName ? ` — owner ${task.ownerName}` : ''}`)
    }
  }
  return lines.join('\n')
}

function teamTool(ctx) {
  return {
    name: TEAM_TOOL,
    description:
      'Create and inspect a TaskBridge agent team. Use action "create" when the user explicitly asks for multiple agents, team delegation, or "组队/多智能体/分工"; it spawns bounded workers from the open TaskBridge plan, optionally an integrator teammate, and creates shared team tasks. The Lead remains the plan owner and final integrator by default.',
    parameters: {
      type: 'object',
      additionalProperties: false,
      properties: {
        action: { type: 'string', enum: ['create', 'status', 'stop'], description: 'create a team | inspect the current team | interrupt teammates' },
        maxAgents: { type: 'integer', description: 'Maximum worker teammates to spawn (2-6; default 3)' },
        integrator: { type: 'string', enum: ['lead', 'teammate'], description: 'Who integrates: the Lead (default) or a spawned integrator teammate' },
        member: { type: 'string', description: 'For stop: optional teammate name; omit to interrupt all teammates' },
      },
      required: ['action'],
    },
    output: output((args, value) => [textBlock(renderTeamResult(value))]),
    isConcurrencySafe: (args) => args?.action === 'status',
    timeoutMs: 300000,
    async execute(args, exec) {
      const agent = requireTopLevelAgent(exec)
      const teams = requireTeamService(ctx)
      const membership = teams.tryMembership(agent)
      if (!membership) throw new Error('This session is not a live Team member; task_team requires Agent Teams.')
      const action = String(args.action ?? '')
      if (action === 'status') {
        return {
          action,
          role: membership.role,
          name: membership.name,
          members: teams.listMembers(agent),
          tasks: teams.listTasks(agent),
        }
      }
      if (membership.role !== 'lead') {
        throw new Error('Only the Team Lead can create or stop teammates')
      }
      if (action === 'stop') {
        const targetName = typeof args.member === 'string' ? args.member.trim() : ''
        const candidates = teams.listMembers(agent).filter(
          (member) => member.role === 'teammate' && (targetName === '' || member.name === targetName),
        )
        if (candidates.length === 0) {
          throw new Error(targetName ? `No teammate named "${targetName}" was found` : 'There are no teammates to stop')
        }
        const stopped = []
        const errors = []
        for (const member of candidates) {
          try {
            const result = teams.interrupt(agent, member.name)
            stopped.push({ name: member.name, previousStatus: result.previousStatus })
          } catch (error) {
            errors.push({ name: member.name, error: teamErrorMessage(error) })
          }
        }
        return {
          action,
          role: membership.role,
          name: membership.name,
          stopped,
          errors,
          members: teams.listMembers(agent),
          tasks: teams.listTasks(agent),
        }
      }
      if (action !== 'create') throw new Error('action must be create, status, or stop')

      const state = ctx.sessionProjections.stateOf(agent.session, PROJECTION_KEY)
      const plan = planFromProjectionState(state)
      if (!plan) throw new Error('No TaskBridge plan exists yet. Call task_plan with action "create" first.')
      const openTasks = (plan.tasks ?? []).filter((task) => task.status !== 'completed')
      if (openTasks.length === 0) throw new Error('The TaskBridge plan has no open tasks to assign')
      const maxAgents = Math.min(6, Math.max(2, Number.isFinite(Number(args.maxAgents)) ? Math.trunc(Number(args.maxAgents)) : 3))
      const workerCount = Math.min(maxAgents, openTasks.length)
      const groups = chunkTasks(openTasks, workerCount)
      const membersBefore = teams.listMembers(agent)
      const usedNames = new Set(membersBefore.map((member) => member.name))
      const provider = teamProvider()
      const workers = []
      const errors = []

      for (let index = 0; index < groups.length; index += 1) {
        const group = groups[index]
        const name = uniqueTeamName(`worker-${index + 1}`, usedNames)
        let teamTask
        try {
          teamTask = await teams.createTask(agent, {
            subject: `Worker ${index + 1}: ${group.map((task) => task.title).join(' / ')}`.slice(0, 180),
            description: [
              `TaskBridge plan: ${plan.title}`,
              plan.goal ? `Goal: ${plan.goal}` : '',
              'Assigned plan tasks:',
              ...group.map(taskLine),
              'Claim this team task, do the work in the shared workspace, run the relevant checks, then complete it and report to lead.',
              'Do not edit the TaskBridge plan.',
            ]
              .filter(Boolean)
              .join('\n'),
            writeScopes: [],
          })
        } catch (error) {
          errors.push({ name, error: `createTask failed: ${teamErrorMessage(error)}` })
          continue
        }
        const worker = {
          name,
          planTaskIds: group.map((task) => task.id),
          teamTaskId: teamTask.id,
          member: null,
        }
        workers.push(worker)
        try {
          const spawned = await teams.spawnTeammate(agent, {
            name,
            description: `TaskBridge worker for ${group.map((task) => task.id).join(', ')}`,
            prompt: [textBlock(workerPrompt(plan, name, group, teamTask))],
            context: 'fresh',
            provider,
            signal: exec.signal,
          })
          worker.member = spawned.member
        } catch (error) {
          errors.push({ name, error: `spawnTeammate failed: ${teamErrorMessage(error)}` })
        }
      }

      let integrator = 'lead'
      if (args.integrator === 'teammate' && workers.some((worker) => worker.member)) {
        integrator = 'teammate'
        const integrationTask = await teams.createTask(agent, {
          subject: 'Integrate TaskBridge worker results',
          description: [
            `TaskBridge plan: ${plan.title}`,
            'Wait for every worker task to complete, review the shared workspace changes, run tests, fix integration defects, and report to lead.',
            'Do not spawn teammates. Do not edit the TaskBridge plan.',
          ].join('\n'),
          blockedBy: workers.map((worker) => worker.teamTaskId),
          writeScopes: [],
        })
        const name = uniqueTeamName('integrator', usedNames)
        try {
          await teams.spawnTeammate(agent, {
            name,
            description: 'TaskBridge integration and final verification',
            prompt: [textBlock(integratorPrompt(plan, workers.map((worker) => ({ id: worker.teamTaskId, subject: worker.name }))))],
            context: 'fresh',
            provider,
            signal: exec.signal,
          })
        } catch (error) {
          errors.push({ name, error: `spawnTeammate failed: ${teamErrorMessage(error)}` })
          integrator = 'lead'
        }
      }

      return {
        action: 'create',
        provider,
        planTitle: plan.title,
        workers: workers.map((worker) => ({
          name: worker.name,
          planTaskIds: worker.planTaskIds,
          teamTaskId: worker.teamTaskId,
          spawned: Boolean(worker.member),
        })),
        integrator,
        members: teams.listMembers(agent),
        tasks: teams.listTasks(agent),
        errors,
      }
    },
  }
}

/* ------------------------------------------------------------ auto advisor -- */

const ADVISOR_NOTE_TTL_MS = 15 * 60 * 1000

/**
 * Observe repeated failures and, after the configured threshold, ask the first
 * enabled text provider for advice that is folded into the dynamic prompt
 * section and announced in the inbox.
 *
 * Failure streaks are per agent and reset on a successful tool result or on
 * idle. Aborts/cancellations never count: the user stopping a turn is not the
 * agent being stuck. Subagent sessions are ignored so one delegated child
 * cannot spend the user's consultant budget.
 */
function createAutoAdvisor(ctx) {
  const streaks = new Map()
  const lastTrigger = new Map()
  const inFlight = new Set()
  const advisorNotes = new Map()
  const evaluating = new Set()

  function reset(sessionId) {
    streaks.delete(sessionId)
  }

  /**
   * Record one observed failure and (re)start the advisor evaluation.
   * @returns a promise settling after the evaluation attempt, for tests.
   */
  function recordFailure(agent, source, errorText) {
    if (!agent?.id || isDelegatedAgent(agent)) return Promise.resolve()
    const current = streaks.get(agent.id) ?? { count: 0, lastError: '', lastAt: 0, source: '' }
    current.count += 1
    current.lastError = String(errorText ?? current.lastError ?? '').slice(0, 4000)
    current.lastAt = Date.now()
    current.source = source
    streaks.set(agent.id, current)
    return evaluate(agent, current).catch((error) => {
      try {
        ctx.logger?.warn?.(`taskbridge: auto-consult evaluation failed: ${String(error)}`)
      } catch {
        /* logging is best-effort */
      }
    })
  }

  async function evaluate(agent, streak) {
    if (evaluating.has(agent.id) || inFlight.has(agent.id)) return
    evaluating.add(agent.id)
    try {
      const config = await readConfig()
      if (!config.autoConsult.enabled) return
      if (!streak || streak.count < config.autoConsult.afterErrors) return
      const now = Date.now()
      const cooldown = config.autoConsult.cooldownSec * 1000
      if (now - (lastTrigger.get(agent.id) ?? 0) < cooldown) return
      const provider = pickProvider(config, 'text')
      if (!provider) {
        lastTrigger.set(agent.id, now)
        await appendAudit({ event: 'auto-consult-skipped', sessionId: agent.id, reason: 'no-text-provider', count: streak.count })
        return
      }
      if (ctx.agents.get(agent.id) !== agent) return
      lastTrigger.set(agent.id, now)
      // Start a fresh streak: the next consultation needs new consecutive failures.
      streaks.set(agent.id, { count: 0, lastError: '', lastAt: now, source: '' })
      inFlight.add(agent.id)
      try {
        const state = ctx.sessionProjections.stateOf(agent.session, PROJECTION_KEY)
        const plan = planFromProjectionState(state)
        const conversation = recentConversationText(agent.session)
        const messages = buildAdvisorMessages({ plan, failure: streak, conversation })
        const result = await callTextProvider(provider, messages, {
          maxTokens: config.autoConsult.maxTokens,
          temperature: 0.2,
        })
        const text = String(result.text ?? '').trim()
        if (!text) throw new Error('external advisor returned an empty answer')
        advisorNotes.set(agent.id, { text: text.slice(0, 6000), at: Date.now(), count: streak.count })
        const notice = buildAdvisorNotice(streak.count)
        try {
          if (agent.status === 'running') agent.inject(notice)
          else agent.followup(notice)
        } catch {
          /* The agent may have stopped between the failure and the advisor answer. */
        }
        await appendAudit({
          event: 'auto-consult',
          sessionId: agent.id,
          provider: provider.name,
          providerId: provider.id,
          count: streak.count,
          ok: true,
        })
      } catch (error) {
        await appendAudit({
          event: 'auto-consult',
          sessionId: agent.id,
          provider: provider.name,
          providerId: provider.id,
          count: streak.count,
          ok: false,
          error: error instanceof Error ? error.message.slice(0, 500) : String(error).slice(0, 500),
        })
      } finally {
        inFlight.delete(agent.id)
      }
    } finally {
      evaluating.delete(agent.id)
    }
  }

  return {
    recordFailure,
    reset,
    noteFor(sessionId) {
      const note = advisorNotes.get(sessionId)
      if (!note) return undefined
      if (Date.now() - note.at > ADVISOR_NOTE_TTL_MS) {
        advisorNotes.delete(sessionId)
        return undefined
      }
      return note
    },
    clear(sessionId) {
      streaks.delete(sessionId)
      lastTrigger.delete(sessionId)
      inFlight.delete(sessionId)
      advisorNotes.delete(sessionId)
    },
  }
}

/* ---------------------------------------------------------------- HTTP API -- */

const ALLOWED_METHODS = 'GET,POST,OPTIONS'

/** Same-origin check: the Web UI fetches these routes from its own origin. */
function isSameOrigin(req) {
  const origin = req.headers?.origin
  const host = req.headers?.host
  if (typeof origin !== 'string' || origin === '' || typeof host !== 'string' || host === '') return false
  try {
    return new URL(origin).host.toLowerCase() === host.toLowerCase()
  } catch {
    return false
  }
}

function applyCors(req, res) {
  if (!isSameOrigin(req)) return
  res.setHeader('access-control-allow-origin', req.headers.origin)
  res.setHeader('vary', 'origin')
  res.setHeader('access-control-allow-methods', ALLOWED_METHODS)
  res.setHeader('access-control-allow-headers', `content-type, ${CONFIG_HEADER}`)
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload)
  res.statusCode = status
  res.setHeader('content-type', 'application/json; charset=utf-8')
  res.setHeader('cache-control', 'no-store')
  res.end(body)
}

async function readJsonBody(req, limit = 1_000_000) {
  let size = 0
  const chunks = []
  for await (const chunk of req) {
    const buffer = typeof chunk === 'string' ? Buffer.from(chunk) : chunk
    size += buffer.length
    if (size > limit) throw new Error('request body too large')
    chunks.push(buffer)
  }
  if (chunks.length === 0) return {}
  const text = Buffer.concat(chunks).toString('utf8')
  const parsed = JSON.parse(text)
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    throw new Error('body must be a JSON object')
  }
  return parsed
}

function pathnameOf(req) {
  try {
    return new URL(req.url ?? '/', 'http://127.0.0.1').pathname.replace(/\/+$/, '') || '/'
  } catch {
    return '/'
  }
}

function configSnapshot(config) {
  return sanitizeConfigForClient(config)
}

function createConfigRoute(ctx) {
  return {
    kind: 'prefix',
    path: ROUTE_BASE,
    async handler(req, res) {
      try {
        applyCors(req, res)
        if (req.method === 'OPTIONS') {
          res.statusCode = 204
          res.end()
          return
        }
        const pathname = pathnameOf(req)
        if (pathname === CONFIG_PATH) {
          if (req.method === 'GET') {
            const config = await readConfig()
            sendJson(res, 200, {
              ok: true,
              config: configSnapshot(config),
              configPath: configPath(),
              auditPath: auditPath(),
            })
            return
          }
          if (req.method === 'POST') {
            if (req.headers?.[CONFIG_HEADER] !== '1') {
              sendJson(res, 403, { ok: false, error: `missing ${CONFIG_HEADER}: 1 header` })
              return
            }
            let body
            try {
              body = await readJsonBody(req)
            } catch (error) {
              sendJson(res, 400, { ok: false, error: error instanceof Error ? error.message : String(error) })
              return
            }
            try {
              const incoming = isRecord(body.config) ? body.config : body
              const existing = await readConfig()
              const next = normalizeConfig(incoming, existing)
              const file = await writeConfig(next)
              sendJson(res, 200, { ok: true, config: configSnapshot(next), configPath: file })
            } catch (error) {
              sendJson(res, 400, { ok: false, error: error instanceof Error ? error.message : String(error) })
            }
            return
          }
          sendJson(res, 405, { ok: false, error: 'method not allowed' })
          return
        }
        if (pathname === HEALTH_PATH) {
          sendJson(res, 200, { ok: true, plugin: name, configPath: configPath() })
          return
        }
        sendJson(res, 404, { ok: false, error: 'not found' })
      } catch (error) {
        try {
          ctx.logger?.warn?.(`taskbridge: config route failed: ${String(error)}`)
        } catch {
          /* logging is best-effort */
        }
        if (!res.headersSent) {
          sendJson(res, 500, { ok: false, error: 'internal error' })
        } else {
          try {
            res.end()
          } catch {
            /* the socket may be gone */
          }
        }
      }
    },
  }
}

/* ------------------------------------------------------------------- apply -- */

export function apply(ctx) {
  const autoAdvisor = createAutoAdvisor(ctx)

  ctx.sessionProjections.register({
    key: PROJECTION_KEY,
    stateVersion: 1,
    stateSchema: PROJECTION_STATE_SCHEMA,
    init: () => initProjectionState(),
    apply: applyProjectionEvent,
    wire: {
      viewSchema: PASSTHROUGH_SCHEMA,
      // The same plan reference while unchanged: the registry suppresses
      // publication by Object.is, so the Client view never re-renders for a
      // pending-only fold and an unchanged plan never leaks a reference change.
      view: (state) => planFromProjectionState(state),
    },
  })

  ctx.tools.register(planTool(ctx))
  ctx.tools.register(updateTool(ctx))
  ctx.tools.register(consultTool())
  ctx.tools.register(mediaTool(ctx))
  ctx.tools.register(teamTool(ctx))

  // `interpolate: false` is load-bearing: plan titles/notes carry model- and
  // user-authored text, and strict `{{variable}}` interpolation would throw on
  // a task note that happens to contain braces, failing the whole assembly.
  ctx.systemPrompt.section({
    name: 'taskbridge:policy',
    order: 620,
    interpolate: false,
    text: (assemblyContext) => {
      const agent = assemblyContext?.agent ?? assemblyContext?.scope
      // Delegated children report through their result; the plan is the
      // user-facing record of the top-level session.
      if (agent && isDelegatedAgent(agent)) return ''
      return PLANNER_POLICY
    },
  })

  ctx.systemPrompt.section({
    name: 'taskbridge:media',
    order: 630,
    interpolate: false,
    text: (assemblyContext) => {
      const agent = assemblyContext?.agent ?? assemblyContext?.scope
      if (agent && isDelegatedAgent(agent)) return ''
      return MEDIA_POLICY
    },
  })

  ctx.systemPrompt.section({
    name: 'taskbridge:team',
    order: 635,
    interpolate: false,
    text: (assemblyContext) => {
      const agent = assemblyContext?.agent ?? assemblyContext?.scope
      if (agent && isDelegatedAgent(agent)) return ''
      return TEAM_POLICY
    },
  })

  ctx.systemPrompt.section({
    name: 'taskbridge:plan',
    order: 640,
    interpolate: false,
    text: (assemblyContext) => {
      try {
        const agent = assemblyContext?.agent ?? assemblyContext?.scope
        if (!agent?.session?.id) return ''
        const state = ctx.sessionProjections.stateOf(agent.session, PROJECTION_KEY)
        const plan = planFromProjectionState(state)
        const note = autoAdvisor.noteFor(agent.id)
        return renderPlanPrompt(plan, note?.text)
      } catch {
        // A prompt section must never fail an assembly: degrade to no section.
        return ''
      }
    },
  })

  ctx.on('agent/request-error', (payload, next) => {
    try {
      if (payload?.signal?.aborted) return next()
      const code = String(payload?.failure?.code ?? '')
      if (/ABORT|CANCEL/i.test(code)) return next()
      void autoAdvisor.recordFailure(
        payload?.agent,
        'request',
        payload?.failure?.message ?? payload?.failure?.code ?? 'model request failed',
      )
    } catch {
      /* observation only */
    }
    return next()
  })

  ctx.on('tools/result', (exec, result) => {
    try {
      if (!exec?.agent) return
      if (exec.name === CONSULT_TOOL || exec.name === MEDIA_TOOL) return
      if (result?.isError) {
        if (exec.signal?.aborted) return
        const info = result.error?.info
        const code = String(info?.code ?? '')
        const text = Array.isArray(result.content)
          ? result.content
              .filter((block) => block?.type === 'text' && typeof block.text === 'string')
              .map((block) => block.text)
              .join('\n')
          : ''
        if (/ABORT|CANCEL/i.test(code) || /tool call aborted/i.test(text)) return
        void autoAdvisor.recordFailure(exec.agent, 'tool', result.error?.message || text || `${exec.name} failed`)
      } else {
        autoAdvisor.reset(exec.agent.id)
      }
    } catch {
      /* observation only */
    }
  })

  ctx.on('agent/status', ({ agent, status } = {}) => {
    if (agent?.id && status === 'idle') autoAdvisor.reset(agent.id)
  })

  ctx.on('agent/disposed', ({ agent } = {}) => {
    if (agent?.id) autoAdvisor.clear(agent.id)
  })

  ctx.effect(() => {
    const dispose = ctx.webServer.register(createConfigRoute(ctx))
    return () => {
      try {
        dispose()
      } catch {
        /* already gone with the server */
      }
    }
  }, 'taskbridge: config route')
}

/* Test-only surface; harmless for the Loader. */
export const __test = {
  configPath,
  planTool,
  updateTool,
  consultTool,
  mediaTool,
  teamTool,
  createConfigRoute,
  createAutoAdvisor,
  renderPlanMarkdown,
}
